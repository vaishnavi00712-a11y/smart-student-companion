# Deploying Smart Student Companion

## Why the old build returned 404

Three things in the previous zip could each cause a 404 on the hosted URL:

1. **`process.cwd()` path resolution.** The server looked for `dist/index.html`
   relative to the working directory. Hosts frequently start the process from a
   different directory, so the lookup missed and every route fell through to a
   404. Paths are now resolved from the bundle's own location (`__dirname`).
2. **Build tooling in `devDependencies`.** `esbuild`, `tailwindcss` and
   `typescript` were dev-only. Hosts that set `NODE_ENV=production` before
   `npm install` skip dev dependencies, so the build silently produced no
   `dist/`, and the running server had nothing to serve. They now live in
   `dependencies`, and the build command passes `--include=dev`.
3. **No SPA fallback on static hosts.** Deep links like `/dashboard` 404'd
   because there was no rewrite rule. `vercel.json`, `netlify.toml` and
   `public/_redirects` now cover that.

## Deploy targets

This is a **full-stack app** (Express API + React frontend). It must run on a
Node web service, not a static-site host, or the `/api/*` routes will not exist.

### Render (recommended — `render.yaml` is included)

Create a **Web Service**, not a Static Site.

- Build command: `npm install --include=dev && npm run build`
- Start command: `npm start`
- Health check path: `/api/health`
- Environment: `NODE_ENV=production`, `JWT_SECRET=<random string>`,
  `GEMINI_API_KEY=<your key>` (optional — AI routes degrade gracefully without it)

### Railway / Fly.io / Heroku

A `Procfile` is included. Same build and start commands as above.

### Local production check

```bash
npm install
npm run build
npm start
# open http://localhost:3000
```

## Verifying a deploy

```bash
curl https://<your-app>/api/health
```

Expected: `{"status":"ok", ...}`.

If it returns `{"status":"frontend-build-missing"}`, the build step did not run
or did not finish — check the build logs for the `vite build` output.

## Environment variables

| Variable | Required | Notes |
| --- | --- | --- |
| `PORT` | no | Injected by the host; defaults to `3000`. |
| `NODE_ENV` | yes | Set to `production` on the host. |
| `JWT_SECRET` | yes | Any long random string. |
| `GEMINI_API_KEY` | no | Enables the AI assistant routes. |
| `DATA_DIR` | no | Point at a mounted disk to persist the JSON store across deploys. |

**Note on persistence:** the JSON store writes to `data/db.json`. On hosts with
ephemeral filesystems (Render free tier, Heroku), that file is wiped on every
restart. Attach a persistent disk and set `DATA_DIR` to it if you need data to
survive.
