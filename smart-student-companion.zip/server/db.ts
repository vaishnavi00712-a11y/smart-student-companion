import fs from "fs";
import path from "path";
import bcrypt from "bcryptjs";
import { v4 as uuidv4 } from "uuid";

export interface UserDocument {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  course: string;
  year: string;
  college: string;
  avatarUrl?: string;
  createdAt: string;
  updatedAt: string;
}

export interface AssignmentDocument {
  id: string;
  userId: string;
  title: string;
  description: string;
  subject: string;
  priority: "Low" | "Medium" | "High";
  status: "Pending" | "In Progress" | "Completed";
  dueDate: string;
  createdAt: string;
  updatedAt: string;
}

export interface SubjectDocument {
  id: string;
  userId: string;
  code: string;
  name: string;
  instructor: string;
  credits: number;
  prerequisites: string[];
}

export interface AttendanceDocument {
  id: string;
  userId: string;
  subject: string;
  present: number;
  total: number;
  updatedAt: string;
}

export interface MarkDocument {
  id: string;
  userId: string;
  subject: string;
  internalMarks: number;
  externalMarks: number;
  maxMarks: number;
  totalMarks: number;
  percentage: number;
  grade: string;
  examType: string;
  updatedAt: string;
}

export interface NoteDocument {
  id: string;
  userId: string;
  title: string;
  content: string;
  subject: string;
  folder?: string;
  tags: string[];
  fileUrl?: string;
  fileName?: string;
  createdAt: string;
  updatedAt: string;
}

export interface StudyGoalDocument {
  id: string;
  userId: string;
  title: string;
  subject: string;
  targetHours: number;
  completedHours: number;
  deadline: string;
  status: "active" | "completed";
  createdAt: string;
}

export interface PomodoroSessionDocument {
  id: string;
  userId: string;
  subject: string;
  durationMinutes: number;
  startTime: string;
  endTime: string;
  completed: boolean;
  notes?: string;
}

export interface CalendarEventDocument {
  id: string;
  userId: string;
  title: string;
  eventType: "Assignment Deadline" | "Exam" | "Study Session" | "College Event" | "Personal Event";
  startDate: string;
  endDate?: string;
  location?: string;
  notes?: string;
}

export interface NotificationDocument {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: "warning" | "info" | "success" | "reminder";
  read: boolean;
  createdAt: string;
}

export interface ActivityLogDocument {
  id: string;
  userId: string;
  action: string;
  entityType: string;
  description: string;
  timestamp: string;
}

export interface FlashcardDocument {
  id: string;
  userId: string;
  subject: string;
  question: string;
  answer: string;
  difficulty: "Easy" | "Medium" | "Hard";
  reviewedCount: number;
  lastReviewed?: string;
}

export interface DatabaseSchema {
  users: UserDocument[];
  assignments: AssignmentDocument[];
  subjects: SubjectDocument[];
  attendance: AttendanceDocument[];
  marks: MarkDocument[];
  notes: NoteDocument[];
  study_goals: StudyGoalDocument[];
  pomodoro_sessions: PomodoroSessionDocument[];
  calendar_events: CalendarEventDocument[];
  notifications: NotificationDocument[];
  activity_logs: ActivityLogDocument[];
  flashcards: FlashcardDocument[];
}

// DATA_DIR lets hosts point the JSON store at a mounted persistent disk.
// Falls back to <project root>/data, resolved from the bundle location so the
// path is correct regardless of the working directory the host starts from.
const PROJECT_ROOT =
  process.env.NODE_ENV === "production" ? path.resolve(__dirname, "..") : process.cwd();
const DB_DIR = process.env.DATA_DIR
  ? path.resolve(process.env.DATA_DIR)
  : path.join(PROJECT_ROOT, "data");
const DB_FILE = path.join(DB_DIR, "db.json");

class DatabaseEngine {
  private data: DatabaseSchema = {
    users: [],
    assignments: [],
    subjects: [],
    attendance: [],
    marks: [],
    notes: [],
    study_goals: [],
    pomodoro_sessions: [],
    calendar_events: [],
    notifications: [],
    activity_logs: [],
    flashcards: [],
  };

  constructor() {
    this.init();
  }

  private init() {
    try {
      if (!fs.existsSync(DB_DIR)) {
        fs.mkdirSync(DB_DIR, { recursive: true });
      }

      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, "utf-8");
        this.data = JSON.parse(raw);
      } else {
        this.seedDemoData();
        this.save();
      }
    } catch (e) {
      console.error("Failed to load database, creating fresh seeded instance:", e);
      this.seedDemoData();
      this.save();
    }
  }

  public save() {
    try {
      if (!fs.existsSync(DB_DIR)) {
        fs.mkdirSync(DB_DIR, { recursive: true });
      }
      fs.writeFileSync(DB_FILE, JSON.stringify(this.data, null, 2), "utf-8");
    } catch (err) {
      console.error("Error saving database file:", err);
    }
  }

  private seedDemoData() {
    const demoUserId = "user-demo-student-001";
    const now = new Date();
    const isoNow = now.toISOString();

    const dPlus = (days: number) => {
      const d = new Date(now);
      d.setDate(d.getDate() + days);
      return d.toISOString();
    };

    const dMinus = (days: number) => {
      const d = new Date(now);
      d.setDate(d.getDate() - days);
      return d.toISOString();
    };

    const salt = bcrypt.genSaltSync(10);
    const passwordHash = bcrypt.hashSync("password123", salt);

    this.data.users = [
      {
        id: demoUserId,
        name: "Alex Rivera",
        email: "alex@student.edu",
        passwordHash,
        course: "B.Tech Computer Science & Engineering",
        year: "3rd Year (Semester 6)",
        college: "Stanford Institute of Technology",
        avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80",
        createdAt: dMinus(60),
        updatedAt: isoNow,
      },
    ];

    this.data.subjects = [
      { id: "sub-1", userId: demoUserId, code: "CS301", name: "Database Management Systems", instructor: "Dr. Aris Vance", credits: 4, prerequisites: ["Data Structures"] },
      { id: "sub-2", userId: demoUserId, code: "CS302", name: "Operating Systems", instructor: "Prof. Elena Rostova", credits: 4, prerequisites: ["Computer Architecture"] },
      { id: "sub-3", userId: demoUserId, code: "CS303", name: "Computer Networks", instructor: "Dr. Marcus Sterling", credits: 3, prerequisites: ["Operating Systems"] },
      { id: "sub-4", userId: demoUserId, code: "CS304", name: "Theory of Computation", instructor: "Prof. Alan Turing Jr.", credits: 4, prerequisites: ["Discrete Mathematics"] },
      { id: "sub-5", userId: demoUserId, code: "CS305", name: "Design & Analysis of Algorithms", instructor: "Dr. Sarah Cormack", credits: 4, prerequisites: ["Data Structures"] },
    ];

    this.data.assignments = [
      {
        id: "assign-1",
        userId: demoUserId,
        title: "B+ Tree Indexing & Query Optimizer Lab",
        description: "Implement disk-based B+ tree node splitting, deletion, and calculate I/O cost metrics for DBMS benchmark.",
        subject: "Database Management Systems",
        priority: "High",
        status: "In Progress",
        dueDate: dPlus(2),
        createdAt: dMinus(5),
        updatedAt: isoNow,
      },
      {
        id: "assign-2",
        userId: demoUserId,
        title: "Multi-threaded CPU Scheduling Simulator",
        description: "Simulate Round Robin, Shortest Job First, and Priority Scheduling with Gantt chart generation.",
        subject: "Operating Systems",
        priority: "High",
        status: "Pending",
        dueDate: dPlus(1),
        createdAt: dMinus(4),
        updatedAt: isoNow,
      },
      {
        id: "assign-3",
        userId: demoUserId,
        title: "TCP Congestion Control & Socket Programming",
        description: "Analyze TCP Tahoe vs Reno congestion window behaviors using Wireshark traces.",
        subject: "Computer Networks",
        priority: "Medium",
        status: "Pending",
        dueDate: dPlus(6),
        createdAt: dMinus(2),
        updatedAt: isoNow,
      },
      {
        id: "assign-4",
        userId: demoUserId,
        title: "Dijkstra and A* Algorithm Performance Benchmarking",
        description: "Empirical comparison of dense vs sparse graph pathfinding with Fibonacci heaps.",
        subject: "Design & Analysis of Algorithms",
        priority: "Medium",
        status: "Completed",
        dueDate: dMinus(1),
        createdAt: dMinus(7),
        updatedAt: dMinus(1),
      },
      {
        id: "assign-5",
        userId: demoUserId,
        title: "Context-Free Grammar & Pushdown Automata Proofs",
        description: "Pumping lemma proofs for non-context-free languages and Chomsky Normal Form conversions.",
        subject: "Theory of Computation",
        priority: "Low",
        status: "Pending",
        dueDate: dPlus(9),
        createdAt: dMinus(1),
        updatedAt: isoNow,
      },
    ];

    // Attendance records (with one shortage to showcase predictive algorithm)
    this.data.attendance = [
      { id: "att-1", userId: demoUserId, subject: "Database Management Systems", present: 38, total: 44, updatedAt: isoNow }, // 86.36% (Safe)
      { id: "att-2", userId: demoUserId, subject: "Operating Systems", present: 34, total: 42, updatedAt: isoNow }, // 80.95% (Safe)
      { id: "att-3", userId: demoUserId, subject: "Computer Networks", present: 26, total: 38, updatedAt: isoNow }, // 68.42% (Shortage Warning!)
      { id: "att-4", userId: demoUserId, subject: "Theory of Computation", present: 31, total: 40, updatedAt: isoNow }, // 77.5% (Safe/Warning)
      { id: "att-5", userId: demoUserId, subject: "Design & Analysis of Algorithms", present: 41, total: 45, updatedAt: isoNow }, // 91.11% (Safe)
    ];

    // Marks records
    this.data.marks = [
      {
        id: "mark-1",
        userId: demoUserId,
        subject: "Database Management Systems",
        internalMarks: 28,
        externalMarks: 64,
        maxMarks: 100,
        totalMarks: 92,
        percentage: 92,
        grade: "A+",
        examType: "Mid-Term Examination",
        updatedAt: dMinus(14),
      },
      {
        id: "mark-2",
        userId: demoUserId,
        subject: "Operating Systems",
        internalMarks: 25,
        externalMarks: 58,
        maxMarks: 100,
        totalMarks: 83,
        percentage: 83,
        grade: "A",
        examType: "Mid-Term Examination",
        updatedAt: dMinus(14),
      },
      {
        id: "mark-3",
        userId: demoUserId,
        subject: "Computer Networks",
        internalMarks: 22,
        externalMarks: 51,
        maxMarks: 100,
        totalMarks: 73,
        percentage: 73,
        grade: "B+",
        examType: "Mid-Term Examination",
        updatedAt: dMinus(14),
      },
      {
        id: "mark-4",
        userId: demoUserId,
        subject: "Theory of Computation",
        internalMarks: 26,
        externalMarks: 53,
        maxMarks: 100,
        totalMarks: 79,
        percentage: 79,
        grade: "B+",
        examType: "Mid-Term Examination",
        updatedAt: dMinus(14),
      },
      {
        id: "mark-5",
        userId: demoUserId,
        subject: "Design & Analysis of Algorithms",
        internalMarks: 29,
        externalMarks: 67,
        maxMarks: 100,
        totalMarks: 96,
        percentage: 96,
        grade: "A+",
        examType: "Mid-Term Examination",
        updatedAt: dMinus(14),
      },
    ];

    // Notes records
    this.data.notes = [
      {
        id: "note-1",
        userId: demoUserId,
        title: "B+ Tree Indexing and Storage Engine Fundamentals",
        content: `A B+ tree is an N-ary search tree with a variable but often large number of children per node. All leaf nodes reside at the exact same depth, maintaining strict balance. 
Key differences between B-Tree and B+ Tree:
1. In B+ trees, data records or pointers are stored exclusively at the leaf level. Internal nodes contain only search keys and child page pointers.
2. Leaf nodes are linked sequentially via bidirectional pointers, making range queries O(log N + K) disk seeks.
3. Node split occurs when keys reach M; the middle key is copied up rather than moved up.
Concurrency control uses crabbing / lock coupling: acquire parent latch, child latch, release parent latch if child is safe.`,
        subject: "Database Management Systems",
        folder: "Unit 3 - Storage & Indexing",
        tags: ["B+Tree", "Indexing", "Storage", "DBMS"],
        createdAt: dMinus(10),
        updatedAt: dMinus(2),
      },
      {
        id: "note-2",
        userId: demoUserId,
        title: "Process Synchronization & Dining Philosophers Solution",
        content: `Synchronization primitives in modern kernels:
1. Mutex: binary semaphore with ownership semantics.
2. Counting Semaphore: initialized with resource counter N. Wait/P decrements, Signal/V increments.
3. Peterson's Algorithm: 2-process software solution using turn variable and flag array.
Dining Philosophers deadlock prevention:
- Asymmetric solution: odd philosophers pick left fork first, even philosophers pick right fork first.
- Monitor solution: test state (THINKING, HUNGRY, EATING) atomically under condition variables.`,
        subject: "Operating Systems",
        folder: "Unit 2 - Concurrency",
        tags: ["OS", "Semaphores", "Concurrency", "Deadlock"],
        createdAt: dMinus(8),
        updatedAt: dMinus(3),
      },
      {
        id: "note-3",
        userId: demoUserId,
        title: "Dynamic Programming: 0/1 Knapsack & Bellman-Ford",
        content: `Dynamic Programming principles:
1. Optimal substructure: optimal solution of problem contains optimal solutions to subproblems.
2. Overlapping subproblems: recursive tree recomputes identical states.
0/1 Knapsack recurrence:
dp[i][w] = max(dp[i-1][w], dp[i-1][w - wt[i]] + val[i])
Bellman-Ford single source shortest path:
Relaxes all |E| edges |V|-1 times. Detects negative weight cycles on the |V|-th relaxation iteration. Time complexity O(V * E).`,
        subject: "Design & Analysis of Algorithms",
        folder: "Unit 4 - Dynamic Programming",
        tags: ["DSA", "Algorithms", "DP", "Knapsack"],
        createdAt: dMinus(6),
        updatedAt: dMinus(1),
      },
    ];

    // Study Goals
    this.data.study_goals = [
      {
        id: "goal-1",
        userId: demoUserId,
        title: "Master DBMS Query Optimization & Indexing",
        subject: "Database Management Systems",
        targetHours: 15,
        completedHours: 11.5,
        deadline: dPlus(5),
        status: "active",
        createdAt: dMinus(12),
      },
      {
        id: "goal-2",
        userId: demoUserId,
        title: "Revise Operating Systems Memory & Virtual Paging",
        subject: "Operating Systems",
        targetHours: 12,
        completedHours: 8,
        deadline: dPlus(8),
        status: "active",
        createdAt: dMinus(9),
      },
      {
        id: "goal-3",
        userId: demoUserId,
        title: "Solve 20 Graph Algorithms LeetCode Problems",
        subject: "Design & Analysis of Algorithms",
        targetHours: 10,
        completedHours: 10,
        deadline: dMinus(1),
        status: "completed",
        createdAt: dMinus(15),
      },
    ];

    // Pomodoro Sessions
    this.data.pomodoro_sessions = [
      { id: "pom-1", userId: demoUserId, subject: "Database Management Systems", durationMinutes: 25, startTime: dMinus(1), endTime: dMinus(1), completed: true, notes: "Read chapter on B-tree locking" },
      { id: "pom-2", userId: demoUserId, subject: "Database Management Systems", durationMinutes: 25, startTime: dMinus(1), endTime: dMinus(1), completed: true, notes: "Implemented leaf node split" },
      { id: "pom-3", userId: demoUserId, subject: "Operating Systems", durationMinutes: 25, startTime: dMinus(2), endTime: dMinus(2), completed: true, notes: "Dining philosophers code trace" },
      { id: "pom-4", userId: demoUserId, subject: "Design & Analysis of Algorithms", durationMinutes: 25, startTime: dMinus(3), endTime: dMinus(3), completed: true, notes: "DP Memoization table exercises" },
      { id: "pom-5", userId: demoUserId, subject: "Computer Networks", durationMinutes: 25, startTime: dMinus(4), endTime: dMinus(4), completed: true, notes: "Subnetting and CIDR calculation" },
      { id: "pom-6", userId: demoUserId, subject: "Database Management Systems", durationMinutes: 25, startTime: dMinus(5), endTime: dMinus(5), completed: true, notes: "ACID properties review" },
    ];

    // Calendar Events
    this.data.calendar_events = [
      { id: "cal-1", userId: demoUserId, title: "DBMS Lab Assignment Submission", eventType: "Assignment Deadline", startDate: dPlus(2), location: "CS Lab 304", notes: "Submit git repo link and benchmark PDF" },
      { id: "cal-2", userId: demoUserId, title: "Operating Systems Mid-Semester Exam", eventType: "Exam", startDate: dPlus(4), location: "Hall B, Science Block", notes: "Syllabus: Chapters 1 through 6" },
      { id: "cal-3", userId: demoUserId, title: "Algorithms Deep Dive Group Study", eventType: "Study Session", startDate: dPlus(1), location: "Library Study Room 4", notes: "Focus on Graph Traversal and MST" },
      { id: "cal-4", userId: demoUserId, title: "Tech Symposium & Hackathon Kickoff", eventType: "College Event", startDate: dPlus(7), location: "Main Auditorium", notes: "Team registration opens at 9 AM" },
    ];

    // Notifications
    this.data.notifications = [
      { id: "notif-1", userId: demoUserId, title: "Shortage Alert: Computer Networks", message: "Your attendance is at 68.42%. You need to attend 10 consecutive classes to reach 75%.", type: "warning", read: false, createdAt: dMinus(1) },
      { id: "notif-2", userId: demoUserId, title: "Assignment Due Soon", message: "Multi-threaded CPU Scheduling Simulator is due tomorrow.", type: "reminder", read: false, createdAt: dMinus(1) },
      { id: "notif-3", userId: demoUserId, title: "Goal Milestone Reached", message: "You completed 10 hours on Algorithms Mastery!", type: "success", read: true, createdAt: dMinus(2) },
    ];

    // Activity Logs (Stack representation for recent student actions)
    this.data.activity_logs = [
      { id: "act-1", userId: demoUserId, action: "POMODORO_COMPLETED", entityType: "Pomodoro", description: "Completed 25-minute focus session on DBMS", timestamp: dMinus(1) },
      { id: "act-2", userId: demoUserId, action: "ASSIGNMENT_UPDATED", entityType: "Assignment", description: "Status changed to In Progress for B+ Tree Indexing", timestamp: dMinus(1) },
      { id: "act-3", userId: demoUserId, action: "ATTENDANCE_RECORDED", entityType: "Attendance", description: "Recorded 1 class attended in OS", timestamp: dMinus(2) },
      { id: "act-4", userId: demoUserId, action: "NOTE_CREATED", entityType: "Notes", description: "Created note 'B+ Tree Indexing and Storage Engine'", timestamp: dMinus(3) },
    ];

    // Flashcards
    this.data.flashcards = [
      { id: "flash-1", userId: demoUserId, subject: "Database Management Systems", question: "What is the primary difference between a clustered and non-clustered index?", answer: "A clustered index alters the physical storage order of data rows on disk (only 1 per table), while a non-clustered index creates a separate sorted lookup tree pointing to row locators.", difficulty: "Medium", reviewedCount: 4, lastReviewed: dMinus(2) },
      { id: "flash-2", userId: demoUserId, subject: "Operating Systems", question: "What are the 4 Coffman conditions required for deadlock to occur?", answer: "1. Mutual Exclusion, 2. Hold and Wait, 3. No Preemption, 4. Circular Wait.", difficulty: "Hard", reviewedCount: 6, lastReviewed: dMinus(1) },
      { id: "flash-3", userId: demoUserId, subject: "Design & Analysis of Algorithms", question: "What is the time complexity of building a Binary Heap from an unsorted array of size N?", answer: "O(N) using Floyd's bottom-up heapify algorithm, not O(N log N).", difficulty: "Medium", reviewedCount: 5, lastReviewed: dMinus(3) },
    ];
  }

  // ==========================================
  // Generic CRUD & MongoDB-like Methods
  // ==========================================

  public getCollection<K extends keyof DatabaseSchema>(collection: K): DatabaseSchema[K] {
    return this.data[collection];
  }

  public find<K extends keyof DatabaseSchema, T = DatabaseSchema[K][number]>(
    collection: K,
    predicate?: (item: any) => boolean
  ): T[] {
    const list = this.data[collection] as any[];
    if (!predicate) return [...list] as T[];
    return list.filter(predicate) as T[];
  }

  public findOne<K extends keyof DatabaseSchema, T = DatabaseSchema[K][number]>(
    collection: K,
    predicate: (item: any) => boolean
  ): T | null {
    const list = this.data[collection] as any[];
    const item = list.find(predicate);
    return item ? ({ ...item } as T) : null;
  }

  public insertOne<K extends keyof DatabaseSchema>(
    collection: K,
    item: any
  ): any {
    if (!item.id) {
      item.id = `${collection.slice(0, 4)}-${uuidv4()}`;
    }
    (this.data[collection] as any[]).push(item);
    this.save();
    return item;
  }

  public updateOne<K extends keyof DatabaseSchema>(
    collection: K,
    predicate: (item: any) => boolean,
    updateFields: Partial<any>
  ): any | null {
    const list = this.data[collection] as any[];
    const index = list.findIndex(predicate);
    if (index === -1) return null;

    list[index] = { ...list[index], ...updateFields, updatedAt: new Date().toISOString() };
    this.save();
    return list[index];
  }

  public deleteOne<K extends keyof DatabaseSchema>(
    collection: K,
    predicate: (item: any) => boolean
  ): boolean {
    const list = this.data[collection] as any[];
    const index = list.findIndex(predicate);
    if (index === -1) return false;

    list.splice(index, 1);
    this.save();
    return true;
  }

  /**
   * Upsert operation (specifically requested for attendance: user_id + subject unique index)
   */
  public upsertAttendance(userId: string, subject: string, present: number, total: number): AttendanceDocument {
    const existing = this.findOne("attendance", (a: AttendanceDocument) => a.userId === userId && a.subject.toLowerCase() === subject.toLowerCase());
    const now = new Date().toISOString();

    if (existing) {
      const updated = this.updateOne("attendance", (a: AttendanceDocument) => a.id === existing.id, {
        present,
        total,
        updatedAt: now,
      });
      return updated;
    } else {
      const newDoc: AttendanceDocument = {
        id: `att-${uuidv4().slice(0, 8)}`,
        userId,
        subject,
        present,
        total,
        updatedAt: now,
      };
      return this.insertOne("attendance", newDoc);
    }
  }

  /**
   * Log an activity for the student (Stack of recent actions)
   */
  public logActivity(userId: string, action: string, entityType: string, description: string): ActivityLogDocument {
    const log: ActivityLogDocument = {
      id: `act-${uuidv4().slice(0, 8)}`,
      userId,
      action,
      entityType,
      description,
      timestamp: new Date().toISOString(),
    };
    this.insertOne("activity_logs", log);
    return log;
  }
}

export const db = new DatabaseEngine();
