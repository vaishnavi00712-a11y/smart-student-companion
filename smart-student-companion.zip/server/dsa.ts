/**
 * DSA Algorithms Module for Smart Student Companion
 * Implements core Data Structures and Algorithms with complexity analysis and execution metrics.
 */

export interface AlgorithmMetrics {
  algorithm: string;
  bestCase: string;
  averageCase: string;
  worstCase: string;
  spaceComplexity: string;
  executionTimeMs: number;
  comparisons: number;
}

// ==========================================
// 1. SORTING ALGORITHMS
// ==========================================

/**
 * Merge Sort: Divide and Conquer stable sorting algorithm.
 * Time Complexity: Best O(n log n), Avg O(n log n), Worst O(n log n)
 * Space Complexity: O(n)
 */
export function mergeSort<T>(
  items: T[],
  compareFn: (a: T, b: T) => number
): { sorted: T[]; metrics: AlgorithmMetrics } {
  const startTime = performance.now();
  let comparisons = 0;

  function merge(left: T[], right: T[]): T[] {
    const result: T[] = [];
    let i = 0;
    let j = 0;

    while (i < left.length && j < right.length) {
      comparisons++;
      if (compareFn(left[i], right[j]) <= 0) {
        result.push(left[i]);
        i++;
      } else {
        result.push(right[j]);
        j++;
      }
    }

    return result.concat(left.slice(i)).concat(right.slice(j));
  }

  function sort(arr: T[]): T[] {
    if (arr.length <= 1) return arr;
    const mid = Math.floor(arr.length / 2);
    const left = sort(arr.slice(0, mid));
    const right = sort(arr.slice(mid));
    return merge(left, right);
  }

  const sorted = sort([...items]);
  const executionTimeMs = Number((performance.now() - startTime).toFixed(3));

  return {
    sorted,
    metrics: {
      algorithm: "Merge Sort",
      bestCase: "O(n log n)",
      averageCase: "O(n log n)",
      worstCase: "O(n log n)",
      spaceComplexity: "O(n)",
      executionTimeMs,
      comparisons,
    },
  };
}

/**
 * Quick Sort: In-place partitioning algorithm.
 * Time Complexity: Best O(n log n), Avg O(n log n), Worst O(n²)
 * Space Complexity: O(log n)
 */
export function quickSort<T>(
  items: T[],
  compareFn: (a: T, b: T) => number
): { sorted: T[]; metrics: AlgorithmMetrics } {
  const startTime = performance.now();
  let comparisons = 0;
  const arr = [...items];

  function sort(low: number, high: number) {
    if (low < high) {
      const pivotIndex = partition(low, high);
      sort(low, pivotIndex - 1);
      sort(pivotIndex + 1, high);
    }
  }

  function partition(low: number, high: number): number {
    const pivot = arr[high];
    let i = low - 1;

    for (let j = low; j < high; j++) {
      comparisons++;
      if (compareFn(arr[j], pivot) <= 0) {
        i++;
        [arr[i], arr[j]] = [arr[j], arr[i]];
      }
    }
    [arr[i + 1], arr[high]] = [arr[high], arr[i + 1]];
    return i + 1;
  }

  sort(0, arr.length - 1);
  const executionTimeMs = Number((performance.now() - startTime).toFixed(3));

  return {
    sorted: arr,
    metrics: {
      algorithm: "Quick Sort",
      bestCase: "O(n log n)",
      averageCase: "O(n log n)",
      worstCase: "O(n²)",
      spaceComplexity: "O(log n)",
      executionTimeMs,
      comparisons,
    },
  };
}

// ==========================================
// 2. SEARCHING ALGORITHMS
// ==========================================

/**
 * Binary Search: Logarithmic search on sorted arrays.
 * Time Complexity: Best O(1), Avg O(log n), Worst O(log n)
 * Space Complexity: O(1)
 */
export function binarySearch<T>(
  sortedItems: T[],
  target: string,
  keyExtractor: (item: T) => string
): { item: T | null; index: number; steps: number; metrics: AlgorithmMetrics } {
  const startTime = performance.now();
  let low = 0;
  let high = sortedItems.length - 1;
  let steps = 0;
  const targetLower = target.toLowerCase();

  while (low <= high) {
    steps++;
    const mid = Math.floor((low + high) / 2);
    const midVal = keyExtractor(sortedItems[mid]).toLowerCase();

    if (midVal === targetLower) {
      return {
        item: sortedItems[mid],
        index: mid,
        steps,
        metrics: {
          algorithm: "Binary Search",
          bestCase: "O(1)",
          averageCase: "O(log n)",
          worstCase: "O(log n)",
          spaceComplexity: "O(1)",
          executionTimeMs: Number((performance.now() - startTime).toFixed(3)),
          comparisons: steps,
        },
      };
    } else if (midVal < targetLower) {
      low = mid + 1;
    } else {
      high = mid - 1;
    }
  }

  return {
    item: null,
    index: -1,
    steps,
    metrics: {
      algorithm: "Binary Search",
      bestCase: "O(1)",
      averageCase: "O(log n)",
      worstCase: "O(log n)",
      spaceComplexity: "O(1)",
      executionTimeMs: Number((performance.now() - startTime).toFixed(3)),
      comparisons: steps,
    },
  };
}

/**
 * Linear Search: Sequential scan for unsorted or prefix/substring matching.
 * Time Complexity: Best O(1), Avg O(n), Worst O(n)
 * Space Complexity: O(1)
 */
export function linearSearch<T>(
  items: T[],
  predicate: (item: T) => boolean
): { results: T[]; steps: number; metrics: AlgorithmMetrics } {
  const startTime = performance.now();
  let steps = 0;
  const results: T[] = [];

  for (let i = 0; i < items.length; i++) {
    steps++;
    if (predicate(items[i])) {
      results.push(items[i]);
    }
  }

  return {
    results,
    steps,
    metrics: {
      algorithm: "Linear Search",
      bestCase: "O(1)",
      averageCase: "O(n)",
      worstCase: "O(n)",
      spaceComplexity: "O(1)",
      executionTimeMs: Number((performance.now() - startTime).toFixed(3)),
      comparisons: steps,
    },
  };
}

// ==========================================
// 3. PRIORITY QUEUE / MAX HEAP (ASSIGNMENT URGENCY)
// ==========================================

export interface PrioritizedItem<T> {
  item: T;
  priorityScore: number; // Higher is more urgent
}

export class PriorityQueue<T> {
  private heap: PrioritizedItem<T>[] = [];

  public insert(item: T, score: number): void {
    this.heap.push({ item, priorityScore: score });
    this.bubbleUp(this.heap.length - 1);
  }

  public extractMax(): PrioritizedItem<T> | null {
    if (this.heap.length === 0) return null;
    const max = this.heap[0];
    const end = this.heap.pop()!;
    if (this.heap.length > 0) {
      this.heap[0] = end;
      this.bubbleDown(0);
    }
    return max;
  }

  public peek(): PrioritizedItem<T> | null {
    return this.heap.length > 0 ? this.heap[0] : null;
  }

  public toSortedArray(): PrioritizedItem<T>[] {
    const clone = new PriorityQueue<T>();
    for (const elem of this.heap) {
      clone.insert(elem.item, elem.priorityScore);
    }
    const result: PrioritizedItem<T>[] = [];
    while (clone.heap.length > 0) {
      const top = clone.extractMax();
      if (top) result.push(top);
    }
    return result;
  }

  private bubbleUp(index: number) {
    const element = this.heap[index];
    while (index > 0) {
      const parentIdx = Math.floor((index - 1) / 2);
      const parent = this.heap[parentIdx];
      if (element.priorityScore <= parent.priorityScore) break;
      this.heap[index] = parent;
      this.heap[parentIdx] = element;
      index = parentIdx;
    }
  }

  private bubbleDown(index: number) {
    const length = this.heap.length;
    const element = this.heap[index];

    while (true) {
      const leftIdx = 2 * index + 1;
      const rightIdx = 2 * index + 2;
      let swapIdx: number | null = null;

      if (leftIdx < length) {
        if (this.heap[leftIdx].priorityScore > element.priorityScore) {
          swapIdx = leftIdx;
        }
      }

      if (rightIdx < length) {
        if (
          (swapIdx === null && this.heap[rightIdx].priorityScore > element.priorityScore) ||
          (swapIdx !== null && this.heap[rightIdx].priorityScore > this.heap[leftIdx].priorityScore)
        ) {
          swapIdx = rightIdx;
        }
      }

      if (swapIdx === null) break;
      this.heap[index] = this.heap[swapIdx];
      this.heap[swapIdx] = element;
      index = swapIdx;
    }
  }
}

/**
 * Calculates Urgency Score for an Assignment based on due date proximity and priority weight.
 * Formula:
 * Urgency = PriorityWeight * 100 + max(0, 100 - DaysUntilDue * 10)
 */
export function computeAssignmentUrgency(dueDate: string, priority: string, status: string): number {
  if (status === "Completed") return 0;
  const now = new Date().getTime();
  const due = new Date(dueDate).getTime();
  const diffDays = (due - now) / (1000 * 60 * 60 * 24);

  const priorityWeights: Record<string, number> = {
    High: 3,
    Medium: 2,
    Low: 1,
  };

  const pWeight = priorityWeights[priority] || 1;
  const daysComponent = diffDays < 0 ? 150 : Math.max(0, Math.round(100 - diffDays * 12));
  return pWeight * 100 + daysComponent;
}

// ==========================================
// 4. ATTENDANCE PREDICTION ALGORITHMS
// ==========================================

export interface AttendanceAnalytics {
  subject: string;
  present: number;
  total: number;
  currentPercentage: number;
  status: "Safe" | "Warning" | "Shortage";
  classesNeededTo75: number;
  classesCanMiss: number;
}

/**
 * Calculates classes needed:
 * ceil((P * T - 100 * A) / (100 - P))
 * where P = target % (75), T = total classes, A = attended
 */
export function calculateAttendancePrediction(
  present: number,
  total: number,
  targetPercentage = 75
): { classesNeeded: number; classesCanMiss: number; currentPercentage: number; status: "Safe" | "Warning" | "Shortage" } {
  if (total === 0) {
    return { classesNeeded: 0, classesCanMiss: 0, currentPercentage: 100, status: "Safe" };
  }

  const currentPercentage = Number(((present / total) * 100).toFixed(2));

  let status: "Safe" | "Warning" | "Shortage" = "Safe";
  if (currentPercentage < 75) {
    status = "Shortage";
  } else if (currentPercentage < 80) {
    status = "Warning";
  }

  // Classes needed to reach target percentage
  let classesNeeded = 0;
  if (currentPercentage < targetPercentage) {
    const numerator = targetPercentage * total - 100 * present;
    const denominator = 100 - targetPercentage;
    classesNeeded = Math.ceil(numerator / denominator);
    if (classesNeeded < 0) classesNeeded = 0;
  }

  // Classes can miss while staying >= target percentage
  let classesCanMiss = 0;
  if (currentPercentage >= targetPercentage) {
    // present / (total + M) >= P/100  =>  100 * present >= P * (total + M) => M <= (100 * present - P * total) / P
    const maxMiss = Math.floor((100 * present - targetPercentage * total) / targetPercentage);
    classesCanMiss = Math.max(0, maxMiss);
  }

  return { classesNeeded, classesCanMiss, currentPercentage, status };
}

// ==========================================
// 5. GRAPH ALGORITHM (PREREQUISITE DEPENDENCY TREE)
// ==========================================

export class PrerequisiteGraph {
  private adjList: Map<string, string[]> = new Map();

  public addSubject(subject: string) {
    if (!this.adjList.has(subject)) {
      this.adjList.set(subject, []);
    }
  }

  public addPrerequisite(subject: string, prerequisite: string) {
    this.addSubject(subject);
    this.addSubject(prerequisite);
    // prerequisite -> subject (prerequisite must be studied before subject)
    const existing = this.adjList.get(prerequisite) || [];
    if (!existing.includes(subject)) {
      existing.push(subject);
      this.adjList.set(prerequisite, existing);
    }
  }

  /**
   * Topological Sort (Kahn's Algorithm using In-Degrees and Queue).
   * Time Complexity: O(V + E)
   */
  public getRecommendedStudyOrder(): { order: string[]; hasCycle: boolean } {
    const inDegree: Map<string, number> = new Map();
    const allNodes = Array.from(this.adjList.keys());

    for (const node of allNodes) {
      inDegree.set(node, 0);
    }

    for (const [, neighbors] of this.adjList.entries()) {
      for (const neighbor of neighbors) {
        inDegree.set(neighbor, (inDegree.get(neighbor) || 0) + 1);
      }
    }

    const queue: string[] = [];
    for (const [node, deg] of inDegree.entries()) {
      if (deg === 0) queue.push(node);
    }

    const order: string[] = [];
    while (queue.length > 0) {
      const curr = queue.shift()!;
      order.push(curr);

      const neighbors = this.adjList.get(curr) || [];
      for (const next of neighbors) {
        inDegree.set(next, inDegree.get(next)! - 1);
        if (inDegree.get(next) === 0) {
          queue.push(next);
        }
      }
    }

    return {
      order,
      hasCycle: order.length !== allNodes.length,
    };
  }
}

// ==========================================
// 6. COSINE SIMILARITY (RAG FOR SMART NOTES)
// ==========================================

/**
 * Computes cosine similarity between two text strings using Term Frequency vectors.
 * Formula: (A · B) / (||A|| × ||B||)
 */
export function cosineSimilarity(textA: string, textB: string): number {
  const tokenize = (t: string) =>
    t
      .toLowerCase()
      .replace(/[^\w\s]/g, "")
      .split(/\s+/)
      .filter((w) => w.length > 2);

  const wordsA = tokenize(textA);
  const wordsB = tokenize(textB);

  if (wordsA.length === 0 || wordsB.length === 0) return 0;

  const freqA: Record<string, number> = {};
  const freqB: Record<string, number> = {};
  const vocab = new Set<string>();

  for (const w of wordsA) {
    freqA[w] = (freqA[w] || 0) + 1;
    vocab.add(w);
  }

  for (const w of wordsB) {
    freqB[w] = (freqB[w] || 0) + 1;
    vocab.add(w);
  }

  let dotProduct = 0;
  let normA = 0;
  let normB = 0;

  for (const w of vocab) {
    const valA = freqA[w] || 0;
    const valB = freqB[w] || 0;
    dotProduct += valA * valB;
    normA += valA * valA;
    normB += valB * valB;
  }

  if (normA === 0 || normB === 0) return 0;
  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

export function searchNotesRAG(
  notes: { id: string; title: string; content: string; subject: string }[],
  query: string,
  topK = 3
): { note: { id: string; title: string; content: string; subject: string }; similarity: number }[] {
  const scored = notes.map((note) => {
    const combined = `${note.title} ${note.subject} ${note.content}`;
    const sim = cosineSimilarity(combined, query);
    return { note, similarity: sim };
  });

  scored.sort((a, b) => b.similarity - a.similarity);
  return scored.slice(0, topK);
}

// ==========================================
// 7. PRODUCTIVITY SCORE ALGORITHM
// ==========================================

export interface ProductivityFactor {
  label: string;
  impact: number;
  description: string;
}

export function calculateProductivityScore(data: {
  completedAssignments: number;
  totalAssignments: number;
  attendanceAvg: number;
  studyHoursThisWeek: number;
  targetStudyHours: number;
  completedGoals: number;
  totalGoals: number;
  pomodoroSessionsCount: number;
}): { score: number; factors: ProductivityFactor[] } {
  let score = 50; // base score
  const factors: ProductivityFactor[] = [];

  // 1. Assignment completion
  if (data.totalAssignments > 0) {
    const ratio = data.completedAssignments / data.totalAssignments;
    if (ratio >= 0.8) {
      score += 15;
      factors.push({ label: "+15 Assignment Completion", impact: 15, description: "Over 80% assignments completed on time." });
    } else if (ratio >= 0.5) {
      score += 8;
      factors.push({ label: "+8 Assignment Progress", impact: 8, description: "Moderate assignment completion rate." });
    } else {
      score -= 10;
      factors.push({ label: "-10 Pending Assignments", impact: -10, description: "Multiple assignments overdue or pending." });
    }
  }

  // 2. Attendance health
  if (data.attendanceAvg >= 85) {
    score += 12;
    factors.push({ label: "+12 Strong Attendance", impact: 12, description: `Average attendance is ${data.attendanceAvg.toFixed(1)}%.` });
  } else if (data.attendanceAvg >= 75) {
    score += 5;
    factors.push({ label: "+5 Safe Attendance", impact: 5, description: "Meeting the 75% minimum requirement." });
  } else {
    score -= 15;
    factors.push({ label: "-15 Attendance Shortage", impact: -15, description: "Attendance is below mandatory 75% threshold." });
  }

  // 3. Study Hours Consistency
  if (data.targetStudyHours > 0) {
    const studyRatio = data.studyHoursThisWeek / data.targetStudyHours;
    if (studyRatio >= 1.0) {
      score += 15;
      factors.push({ label: "+15 Target Study Met", impact: 15, description: `Logged ${data.studyHoursThisWeek}h of target ${data.targetStudyHours}h.` });
    } else if (studyRatio >= 0.6) {
      score += 8;
      factors.push({ label: "+8 Good Study Effort", impact: 8, description: `Completed ${data.studyHoursThisWeek}h toward weekly target.` });
    } else {
      score -= 8;
      factors.push({ label: "-8 Study Deficit", impact: -8, description: "Behind on target weekly study hours." });
    }
  }

  // 4. Pomodoro focus sessions
  if (data.pomodoroSessionsCount >= 10) {
    score += 10;
    factors.push({ label: "+10 Deep Focus Streak", impact: 10, description: `${data.pomodoroSessionsCount} focused Pomodoro cycles completed.` });
  } else if (data.pomodoroSessionsCount >= 4) {
    score += 5;
    factors.push({ label: "+5 Active Focus Sessions", impact: 5, description: "Regular study intervals recorded." });
  }

  // 5. Goals accomplishment
  if (data.totalGoals > 0 && data.completedGoals > 0) {
    const goalRatio = data.completedGoals / data.totalGoals;
    if (goalRatio >= 0.7) {
      score += 8;
      factors.push({ label: "+8 Goals Mastered", impact: 8, description: `${data.completedGoals} study goals checked off.` });
    }
  }

  const boundedScore = Math.max(10, Math.min(99, Math.round(score)));
  return { score: boundedScore, factors };
}
