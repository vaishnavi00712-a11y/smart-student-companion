import React, { useState, useEffect } from "react";
import { Sidebar, NavTab } from "./components/Sidebar";
import { Navbar } from "./components/Navbar";
import { DashboardView } from "./components/DashboardView";
import { AssignmentsView } from "./components/AssignmentsView";
import { AttendanceView } from "./components/AttendanceView";
import { MarksView } from "./components/MarksView";
import { NotesView } from "./components/NotesView";
import { PomodoroView } from "./components/PomodoroView";
import { GoalsView } from "./components/GoalsView";
import { CalendarView } from "./components/CalendarView";
import { AiAssistantView } from "./components/AiAssistantView";
import { AuthModal } from "./components/AuthModal";
import { ProfileModal } from "./components/ProfileModal";
import { User } from "./types";
import { api, getStoredToken, removeStoredToken } from "./services/api";

export default function App() {
  const [currentTab, setCurrentTab] = useState<NavTab>("dashboard");
  const [user, setUser] = useState<User | null>(null);
  const [loadingUser, setLoadingUser] = useState(true);

  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [productivityScore, setProductivityScore] = useState(82);

  // Authenticate on mount or auto-login demo student
  useEffect(() => {
    const initAuth = async () => {
      setLoadingUser(true);
      const token = getStoredToken();
      if (token) {
        try {
          const res = await api.auth.me();
          setUser(res.user);
        } catch {
          removeStoredToken();
          // Fallback to demo login for friction-free preview experience
          await autoLoginDemo();
        }
      } else {
        await autoLoginDemo();
      }
      setLoadingUser(false);
    };

    const autoLoginDemo = async () => {
      try {
        const res = await api.auth.login({
          email: "alex@student.edu",
          password: "password123",
        });
        setUser(res.user);
      } catch (e) {
        console.error("Auto demo login error", e);
      }
    };

    initAuth();
  }, []);

  // Fetch productivity score periodically
  useEffect(() => {
    if (user) {
      api.analytics
        .productivity()
        .then((res) => {
          setProductivityScore(res.productivityScore);
        })
        .catch(() => {});
    }
  }, [user, currentTab]);

  const handleLogout = () => {
    removeStoredToken();
    setUser(null);
    setIsAuthModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex font-sans antialiased">
      {/* Responsive Sidebar */}
      <Sidebar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        user={user}
        onOpenProfile={() => (user ? setIsProfileModalOpen(true) : setIsAuthModalOpen(true))}
        onLogout={handleLogout}
        isOpen={isMobileSidebarOpen}
        onCloseMobile={() => setIsMobileSidebarOpen(false)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 lg:pl-64">
        {/* Sticky Top Navbar */}
        <Navbar
          user={user}
          onToggleSidebar={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
          onOpenAI={() => setCurrentTab("ai-assistant")}
          productivityScore={productivityScore}
        />

        {/* View Router */}
        <main className="flex-1 pb-16">
          {currentTab === "dashboard" && (
            <DashboardView user={user} onNavigate={(tab) => setCurrentTab(tab)} />
          )}
          {currentTab === "assignments" && <AssignmentsView />}
          {currentTab === "attendance" && <AttendanceView />}
          {currentTab === "marks" && <MarksView />}
          {currentTab === "notes" && <NotesView />}
          {currentTab === "pomodoro" && <PomodoroView />}
          {currentTab === "goals" && <GoalsView />}
          {currentTab === "calendar" && <CalendarView />}
          {currentTab === "ai-assistant" && <AiAssistantView />}
        </main>
      </div>

      {/* Auth Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onSuccess={(loggedUser) => {
          setUser(loggedUser);
          setIsAuthModalOpen(false);
        }}
      />

      {/* Profile & Settings Modal */}
      <ProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        user={user}
        onUserUpdated={(updated) => setUser(updated)}
      />
    </div>
  );
}
