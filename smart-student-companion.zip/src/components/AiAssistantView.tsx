import React, { useState } from "react";
import {
  Sparkles,
  MessageSquare,
  FileText,
  HelpCircle,
  Calendar,
  Send,
  Bot,
  CheckCircle2,
  XCircle,
  Clock,
  BookOpen,
  ArrowRight,
  BrainCircuit,
} from "lucide-react";
import { api } from "../services/api";

export const AiAssistantView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<"ask" | "summarize" | "quiz" | "plan">("ask");

  // Tab 1: Ask / Tutor Chat
  const [chatMessages, setChatMessages] = useState<
    { sender: "user" | "ai"; text: string; timestamp: string }[]
  >([
    {
      sender: "ai",
      text: "Hello! I am your AI Academic Tutor powered by Google Gemini. Ask me to explain any complex computer science concept, derive mathematical formulas, or break down algorithms step-by-step.",
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    },
  ]);
  const [userPrompt, setUserPrompt] = useState("");
  const [isAsking, setIsAsking] = useState(false);

  // Tab 2: Summarize
  const [summarizeTitle, setSummarizeTitle] = useState("");
  const [summarizeContent, setSummarizeContent] = useState("");
  const [summaryResult, setSummaryResult] = useState("");
  const [isSummarizing, setIsSummarizing] = useState(false);

  // Tab 3: Practice Quiz
  const [quizTopic, setQuizTopic] = useState("Database Indexing, B-Trees and Normalization");
  const [isGeneratingQuiz, setIsGeneratingQuiz] = useState(false);
  const [quizData, setQuizData] = useState<{
    mcqs: { question: string; options: string[]; correctIndex: number; explanation: string }[];
    trueFalse: { statement: string; isTrue: boolean; explanation: string }[];
    shortQuestions: { question: string; modelAnswer: string }[];
  } | null>(null);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [revealedExplanations, setRevealedExplanations] = useState<Record<number, boolean>>({});

  // Tab 4: Study Plan
  const [availableHours, setAvailableHours] = useState(3);
  const [isGeneratingPlan, setIsGeneratingPlan] = useState(false);
  const [studyPlanData, setStudyPlanData] = useState<{
    weeklySchedule: { day: string; blocks: { timeSlot: string; subject: string; task: string; focusType: string }[] }[];
    recommendations: string[];
  } | null>(null);

  // Handlers
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userPrompt.trim() || isAsking) return;

    const query = userPrompt.trim();
    setUserPrompt("");
    const newMsg = {
      sender: "user" as const,
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };
    setChatMessages((prev) => [...prev, newMsg]);
    setIsAsking(true);

    try {
      const res = await api.ai.ask(query);
      setChatMessages((prev) => [
        ...prev,
        {
          sender: "ai",
          text: res.answer,
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        },
      ]);
    } catch (err) {
      console.error(err);
      setChatMessages((prev) => [
        ...prev,
        {
          sender: "ai",
          text: "I encountered an error answering your request. Please ensure the backend is active.",
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        },
      ]);
    } finally {
      setIsAsking(false);
    }
  };

  const handleRunSummarize = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!summarizeContent.trim()) return;

    setIsSummarizing(true);
    setSummaryResult("");
    try {
      const res = await api.ai.summarize(summarizeTitle || "Lecture Notes", summarizeContent);
      setSummaryResult(res.summary);
    } catch (err) {
      console.error(err);
      setSummaryResult("Failed to generate summary. Please check connection.");
    } finally {
      setIsSummarizing(false);
    }
  };

  const handleGenerateQuiz = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!quizTopic.trim()) return;

    setIsGeneratingQuiz(true);
    setQuizData(null);
    setSelectedAnswers({});
    setRevealedExplanations({});
    try {
      const res = await api.ai.quiz(quizTopic);
      setQuizData(res.quiz);
    } catch (err: any) {
      console.error(err);
      alert(err?.message || "Error generating quiz");
    } finally {
      setIsGeneratingQuiz(false);
    }
  };

  const handleGeneratePlan = async () => {
    setIsGeneratingPlan(true);
    setStudyPlanData(null);
    try {
      const res = await api.ai.studyPlan(availableHours);
      setStudyPlanData(res.plan);
    } catch (err: any) {
      console.error(err);
      alert(err?.message || "Error creating study plan");
    } finally {
      setIsGeneratingPlan(false);
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2.5">
            <Sparkles className="w-6 h-6 text-indigo-600" />
            <span>AI Study Assistant & Academic Coach</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Powered by Google Gemini: Concept Explainer, Note Summarizer, Dynamic Exam Quizzes, and Adaptive 7-Day Plans.
          </p>
        </div>

        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold self-start sm:self-auto">
          <BrainCircuit className="w-3.5 h-3.5 text-indigo-600" />
          <span>Model: Gemini 3.8 Flash</span>
        </div>
      </div>

      {/* Tabs Bar */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab("ask")}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
            activeTab === "ask"
              ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/20"
              : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>Ask Concept / Tutor Chat</span>
        </button>

        <button
          onClick={() => setActiveTab("summarize")}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
            activeTab === "summarize"
              ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/20"
              : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Summarize Notes</span>
        </button>

        <button
          onClick={() => setActiveTab("quiz")}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
            activeTab === "quiz"
              ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/20"
              : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
          }`}
        >
          <HelpCircle className="w-4 h-4" />
          <span>Practice Exam Quiz</span>
        </button>

        <button
          onClick={() => setActiveTab("plan")}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
            activeTab === "plan"
              ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/20"
              : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>7-Day Adaptive Study Plan</span>
        </button>
      </div>

      {/* TAB 1: ASK CONCEPT / TUTOR */}
      {activeTab === "ask" && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs flex flex-col h-[650px] overflow-hidden">
          {/* Chat Messages Log */}
          <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4">
            {chatMessages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex items-start gap-3 ${
                  msg.sender === "user" ? "flex-row-reverse" : "flex-row"
                }`}
              >
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 text-xs font-bold ${
                    msg.sender === "user"
                      ? "bg-indigo-600 text-white"
                      : "bg-indigo-100 text-indigo-700 border border-indigo-200"
                  }`}
                >
                  {msg.sender === "user" ? "You" : <Bot className="w-4 h-4" />}
                </div>

                <div
                  className={`max-w-2xl rounded-2xl p-4 text-xs leading-relaxed ${
                    msg.sender === "user"
                      ? "bg-indigo-600 text-white"
                      : "bg-slate-50 border border-slate-200 text-slate-800"
                  }`}
                >
                  <div className="whitespace-pre-wrap">{msg.text}</div>
                  <span
                    className={`block text-[10px] mt-1.5 ${
                      msg.sender === "user" ? "text-indigo-200" : "text-slate-400"
                    }`}
                  >
                    {msg.timestamp}
                  </span>
                </div>
              </div>
            ))}

            {isAsking && (
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center">
                  <Bot className="w-4 h-4 animate-spin" />
                </div>
                <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs text-slate-500 flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
                  <span>Thinking and composing academic answer...</span>
                </div>
              </div>
            )}
          </div>

          {/* Prompt Input Form */}
          <div className="p-4 border-t border-slate-200 bg-slate-50">
            <form onSubmit={handleSendMessage} className="flex items-center gap-2">
              <input
                type="text"
                value={userPrompt}
                onChange={(e) => setUserPrompt(e.target.value)}
                placeholder="Ask about dynamic programming, deadlock prevention, normalization, OSI layers..."
                className="flex-1 px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
              />
              <button
                type="submit"
                disabled={isAsking || !userPrompt.trim()}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md shadow-indigo-600/20 transition-all"
              >
                <span>Send</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>
        </div>
      )}

      {/* TAB 2: SUMMARIZE */}
      {activeTab === "summarize" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <FileText className="w-4 h-4 text-indigo-600" />
              <span>Input Lecture Notes for AI Synthesis</span>
            </h3>

            <form onSubmit={handleRunSummarize} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Subject / Topic Title
                </label>
                <input
                  type="text"
                  value={summarizeTitle}
                  onChange={(e) => setSummarizeTitle(e.target.value)}
                  placeholder="e.g. ACID Properties & Concurrency Control"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Lecture Content / Paragraphs
                </label>
                <textarea
                  rows={12}
                  required
                  value={summarizeContent}
                  onChange={(e) => setSummarizeContent(e.target.value)}
                  placeholder="Paste lecture transcript, reading notes, textbook paragraphs here..."
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono"
                />
              </div>

              <button
                type="submit"
                disabled={isSummarizing || !summarizeContent.trim()}
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-600/20 flex items-center justify-center gap-2"
              >
                {isSummarizing ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Analyzing and distilling key exam takeaways...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Generate Structured Summary</span>
                  </>
                )}
              </button>
            </form>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col">
            <h3 className="text-sm font-bold text-slate-900 pb-3 border-b border-slate-100 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-600" />
              <span>AI Exam Takeaways & Key Concepts</span>
            </h3>

            <div className="flex-1 mt-4 overflow-y-auto">
              {summaryResult ? (
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 whitespace-pre-wrap leading-relaxed">
                  {summaryResult}
                </div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-center p-8 text-slate-400">
                  <FileText className="w-10 h-10 mb-2 opacity-40" />
                  <p className="text-xs">
                    Your distilled study notes, bulleted takeaways, and formula summaries will appear here.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: QUIZ */}
      {activeTab === "quiz" && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-indigo-600" />
              <span>Generate Interactive Practice Exam</span>
            </h3>

            <form onSubmit={handleGenerateQuiz} className="flex flex-col sm:flex-row gap-3">
              <input
                type="text"
                required
                value={quizTopic}
                onChange={(e) => setQuizTopic(e.target.value)}
                placeholder="Topic: e.g. Dijkstra vs Bellman-Ford, CPU Scheduling, SQL Subqueries"
                className="flex-1 px-4 py-2.5 border border-slate-200 rounded-xl text-xs"
              />
              <button
                type="submit"
                disabled={isGeneratingQuiz}
                className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-600/20 flex items-center justify-center gap-2 shrink-0"
              >
                {isGeneratingQuiz ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Generating Quiz...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Generate Practice Questions</span>
                  </>
                )}
              </button>
            </form>
          </div>

          {quizData && (
            <div className="space-y-6">
              {/* MCQs */}
              <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  Multiple Choice Questions (MCQs)
                </h4>

                <div className="space-y-6">
                  {quizData.mcqs.map((q, qIndex) => {
                    const chosen = selectedAnswers[qIndex];
                    const isAnswered = chosen !== undefined;
                    const isCorrect = chosen === q.correctIndex;
                    const showExplanation = revealedExplanations[qIndex];

                    return (
                      <div
                        key={qIndex}
                        className="p-5 rounded-xl border border-slate-200/80 bg-slate-50/50 space-y-3"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <span className="text-xs font-bold text-slate-900">
                            Q{qIndex + 1}. {q.question}
                          </span>
                          {isAnswered && (
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded flex items-center gap-1 ${
                                isCorrect
                                  ? "bg-emerald-100 text-emerald-800"
                                  : "bg-rose-100 text-rose-800"
                              }`}
                            >
                              {isCorrect ? (
                                <>
                                  <CheckCircle2 className="w-3 h-3" /> Correct!
                                </>
                              ) : (
                                <>
                                  <XCircle className="w-3 h-3" /> Incorrect
                                </>
                              )}
                            </span>
                          )}
                        </div>

                        {/* Options */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                          {q.options.map((opt, optIdx) => {
                            let optClass =
                              "bg-white border-slate-200 text-slate-700 hover:border-indigo-400";
                            if (isAnswered) {
                              if (optIdx === q.correctIndex) {
                                optClass =
                                  "bg-emerald-50 border-emerald-400 text-emerald-900 font-semibold";
                              } else if (optIdx === chosen) {
                                optClass =
                                  "bg-rose-50 border-rose-400 text-rose-900 font-semibold";
                              } else {
                                optClass = "bg-white border-slate-200 opacity-60";
                              }
                            }

                            return (
                              <button
                                key={optIdx}
                                disabled={isAnswered}
                                onClick={() => {
                                  setSelectedAnswers((prev) => ({ ...prev, [qIndex]: optIdx }));
                                  setRevealedExplanations((prev) => ({ ...prev, [qIndex]: true }));
                                }}
                                className={`p-3 rounded-lg border text-left text-xs transition-all ${optClass}`}
                              >
                                <span className="font-bold mr-2 text-slate-400">
                                  {String.fromCharCode(65 + optIdx)}.
                                </span>
                                <span>{opt}</span>
                              </button>
                            );
                          })}
                        </div>

                        {/* Explanation */}
                        {showExplanation && (
                          <div className="p-3 rounded-lg bg-indigo-50/70 border border-indigo-100 text-xs text-indigo-900 leading-relaxed">
                            <strong>Explanation:</strong> {q.explanation}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Short Answer Questions */}
              {quizData.shortQuestions && quizData.shortQuestions.length > 0 && (
                <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
                  <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                    Short Answer Model Questions
                  </h4>

                  <div className="space-y-4">
                    {quizData.shortQuestions.map((sq, i) => (
                      <div key={i} className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
                        <strong className="text-slate-900 block font-bold">
                          {i + 1}. {sq.question}
                        </strong>
                        <div className="p-3 bg-white rounded-lg border border-slate-200 text-slate-700 leading-relaxed">
                          <span className="text-[10px] font-bold text-indigo-600 block uppercase">
                            Model Answer:
                          </span>
                          {sq.modelAnswer}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* TAB 4: STUDY PLAN */}
      {activeTab === "plan" && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Calendar className="w-4 h-4 text-indigo-600" />
                <span>Adaptive 7-Day Academic Study Planner</span>
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Generates a timetable considering your pending assignments, exam proximity, and available daily focus slots.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <label className="text-xs font-semibold text-slate-700">Hours/day:</label>
                <input
                  type="number"
                  min="1"
                  max="10"
                  value={availableHours}
                  onChange={(e) => setAvailableHours(Number(e.target.value))}
                  className="w-16 px-2 py-1 border border-slate-200 rounded-lg text-xs font-bold text-center"
                />
              </div>

              <button
                onClick={handleGeneratePlan}
                disabled={isGeneratingPlan}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-600/20 flex items-center gap-2 shrink-0"
              >
                {isGeneratingPlan ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Synthesizing Plan...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Generate 7-Day Plan</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {studyPlanData && (
            <div className="space-y-6">
              {/* Schedule Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {studyPlanData.weeklySchedule.map((dayPlan, dIdx) => (
                  <div
                    key={dIdx}
                    className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs space-y-3"
                  >
                    <div className="pb-2 border-b border-slate-100 flex items-center justify-between">
                      <h4 className="text-xs font-extrabold text-slate-900 uppercase tracking-wider">
                        {dayPlan.day}
                      </h4>
                      <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">
                        {dayPlan.blocks.length} Sessions
                      </span>
                    </div>

                    <div className="space-y-2">
                      {dayPlan.blocks.map((block, bIdx) => (
                        <div
                          key={bIdx}
                          className="p-3 rounded-lg bg-slate-50 border border-slate-100 text-xs space-y-1"
                        >
                          <div className="flex items-center justify-between text-[10px] text-slate-500">
                            <span className="font-semibold text-slate-700">{block.timeSlot}</span>
                            <span className="bg-slate-200/80 px-1.5 py-0.2 rounded font-medium">
                              {block.focusType}
                            </span>
                          </div>
                          <strong className="text-indigo-950 block truncate">{block.subject}</strong>
                          <p className="text-[11px] text-slate-600 leading-snug">{block.task}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              {/* Recommendations */}
              {studyPlanData.recommendations && studyPlanData.recommendations.length > 0 && (
                <div className="p-5 rounded-xl bg-gradient-to-r from-indigo-950 to-slate-900 text-white border border-slate-800 shadow-sm space-y-2">
                  <h4 className="text-xs font-bold text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Academic Strategy & Revision Recommendations</span>
                  </h4>
                  <ul className="text-xs text-slate-200 space-y-1 list-disc list-inside">
                    {studyPlanData.recommendations.map((rec, rIdx) => (
                      <li key={rIdx}>{rec}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
