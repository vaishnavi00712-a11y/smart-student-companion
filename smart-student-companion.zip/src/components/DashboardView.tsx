import React, { useState, useEffect } from "react";
import {
  CheckSquare,
  UserCheck,
  Target,
  Flame,
  Calendar,
  Clock,
  ArrowRight,
  TrendingUp,
  Sparkles,
  Zap,
  Activity,
  Layers,
} from "lucide-react";
import { NavTab } from "./Sidebar";
import { User, Assignment, AttendanceSummary, UrgentItem, ProductivityData, CalendarEvent } from "../types";
import { api } from "../services/api";

interface DashboardViewProps {
  user: User | null;
  onNavigate: (tab: NavTab) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ user, onNavigate }) => {
  const [loading, setLoading] = useState(true);

  const [pendingAssignmentsCount, setPendingAssignmentsCount] = useState(0);
  const [dueSoonCount, setDueSoonCount] = useState(0);
  const [attendanceSummary, setAttendanceSummary] = useState<AttendanceSummary>({
    overallPercentage: 82,
    totalSubjects: 5,
    safeCount: 4,
    shortageCount: 1,
    warningCount: 0,
  });
  const [productivityData, setProductivityData] = useState<ProductivityData | null>(null);
  const [urgentAssignments, setUrgentAssignments] = useState<UrgentItem[]>([]);
  const [nearestExam, setNearestExam] = useState<CalendarEvent | null>(null);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const [assignRes, attendRes, urgentRes, prodRes, calRes] = await Promise.all([
        api.assignments.list(),
        api.attendance.list(),
        api.assignments.getUrgentHeap(),
        api.analytics.productivity(),
        api.calendar.list(),
      ]);

      const assignments = assignRes.assignments;
      const pending = assignments.filter((a) => a.status !== "Completed").length;
      setPendingAssignmentsCount(pending);

      // Due soon: within next 3 days
      const now = new Date().getTime();
      const threeDays = 3 * 24 * 60 * 60 * 1000;
      const soon = assignments.filter((a) => {
        if (a.status === "Completed") return false;
        const due = new Date(a.dueDate).getTime();
        return due - now > 0 && due - now <= threeDays;
      }).length;
      setDueSoonCount(soon);

      setAttendanceSummary(attendRes.summary);
      setUrgentAssignments(urgentRes.urgentAssignments.slice(0, 3));
      setProductivityData(prodRes);

      // Nearest exam
      const exams = calRes.events.filter((e) => e.eventType === "Exam");
      const upcomingExams = exams.filter((e) => new Date(e.startDate).getTime() >= now);
      if (upcomingExams.length > 0) {
        setNearestExam(upcomingExams[0]);
      }
    } catch (err: any) {
      // Fall back to the existing/default data instead of blocking the whole
      // dashboard with an error banner.
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, [user]);

  if (loading) {
    return (
      <div className="p-8 flex flex-col items-center justify-center min-h-[60vh]">
        <div className="w-10 h-10 border-3 border-cyan-500 border-t-transparent rounded-full animate-spin mb-4" />
        <p className="text-sm font-medium text-slate-500">Loading personalized academic dashboard...</p>
      </div>
    );
  }

  const pScore = productivityData?.productivityScore || 78;

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Hero Welcome Card */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 p-6 sm:p-8 text-white shadow-xl">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/20 border border-cyan-400/30 text-cyan-300 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>Smart Student Companion Engine Active</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              Good Morning, {user?.name || "Student"} 👋
            </h2>
            <p className="text-sm text-slate-300 max-w-xl">
              You have <span className="text-amber-300 font-semibold">{pendingAssignmentsCount} assignments pending</span>{" "}
              and <span className="text-rose-300 font-semibold">{dueSoonCount} due within 72 hours</span>. All algorithms and MongoDB stores are synced.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigate("pomodoro")}
              className="px-4 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-lg shadow-cyan-500/25 transition-all"
            >
              <Clock className="w-4 h-4" />
              <span>Start Pomodoro</span>
            </button>
            <button
              onClick={() => onNavigate("ai-assistant")}
              className="px-4 py-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 text-white font-semibold text-xs flex items-center gap-2 transition-all"
            >
              <Sparkles className="w-4 h-4 text-indigo-400" />
              <span>AI Study Tutor</span>
            </button>
          </div>
        </div>

        {/* Decorative ambient blur */}
        <div className="absolute top-0 right-0 -mt-8 -mr-8 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* 4 Core Summary Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
        {/* Card 1: Assignments */}
        <div
          onClick={() => onNavigate("assignments")}
          className="p-5 rounded-xl bg-white border border-slate-200/90 shadow-xs hover:shadow-md hover:border-cyan-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Assignments</span>
            <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
              <CheckSquare className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900">{pendingAssignmentsCount}</span>
            <span className="text-xs font-semibold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-md">
              {dueSoonCount} Due Soon
            </span>
          </div>
          <p className="mt-2 text-xs text-slate-500 flex items-center justify-between">
            <span>Prioritized via Max-Heap</span>
            <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:translate-x-1 transition-transform" />
          </p>
        </div>

        {/* Card 2: Attendance */}
        <div
          onClick={() => onNavigate("attendance")}
          className="p-5 rounded-xl bg-white border border-slate-200/90 shadow-xs hover:shadow-md hover:border-emerald-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Attendance Health</span>
            <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
              <UserCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900">{attendanceSummary.overallPercentage}%</span>
            <span
              className={`text-xs font-semibold px-2 py-0.5 rounded-md ${
                attendanceSummary.overallPercentage >= 75
                  ? "bg-emerald-50 text-emerald-700"
                  : "bg-rose-50 text-rose-700"
              }`}
            >
              {attendanceSummary.overallPercentage >= 75 ? "Safe" : "Shortage Warning"}
            </span>
          </div>
          <p className="mt-2 text-xs text-slate-500 flex items-center justify-between">
            <span>
              {attendanceSummary.shortageCount > 0
                ? `${attendanceSummary.shortageCount} subject requires classes`
                : "All subjects >= 75%"}
            </span>
            <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:translate-x-1 transition-transform" />
          </p>
        </div>

        {/* Card 3: Study Goals */}
        <div
          onClick={() => onNavigate("goals")}
          className="p-5 rounded-xl bg-white border border-slate-200/90 shadow-xs hover:shadow-md hover:border-purple-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Study Goal</span>
            <div className="p-2 rounded-lg bg-purple-50 text-purple-600 group-hover:bg-purple-600 group-hover:text-white transition-colors">
              <Target className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              {productivityData?.metrics.studyHoursThisWeek || 11.5}h
            </span>
            <span className="text-xs text-slate-500">
              / {productivityData?.metrics.targetStudyHours || 15}h Target
            </span>
          </div>
          {/* Visual Mini Progress Bar */}
          <div className="mt-3 w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
            <div
              className="bg-purple-600 h-1.5 rounded-full transition-all"
              style={{
                width: `${Math.min(
                  100,
                  (((productivityData?.metrics.studyHoursThisWeek || 11.5) /
                    (productivityData?.metrics.targetStudyHours || 15)) *
                    100)
                )}%`,
              }}
            />
          </div>
        </div>

        {/* Card 4: Productivity Score */}
        <div
          onClick={() => onNavigate("goals")}
          className="p-5 rounded-xl bg-white border border-slate-200/90 shadow-xs hover:shadow-md hover:border-cyan-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Productivity Score</span>
            <div className="p-2 rounded-lg bg-cyan-50 text-cyan-600 group-hover:bg-cyan-600 group-hover:text-white transition-colors">
              <Flame className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-cyan-600">{pScore}</span>
            <span className="text-xs font-semibold text-slate-500">/ 100</span>
          </div>
          <p className="mt-2 text-xs text-slate-500 flex items-center justify-between">
            <span>Calculated from 5 metrics</span>
            <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:translate-x-1 transition-transform" />
          </p>
        </div>
      </div>

      {/* Middle Grid: Urgency Priority Queue (Heap) & Nearest Exam Alert */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Urgent Assignments (Max-Heap) - 2 Cols */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-500" />
              <h3 className="text-sm font-bold text-slate-900">
                Most Urgent Tasks
              </h3>
            </div>
          </div>

          <div className="space-y-3">
            {urgentAssignments.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-400">
                No urgent pending assignments found. All caught up!
              </div>
            ) : (
              urgentAssignments.map((urgent, idx) => (
                <div
                  key={urgent.item.id}
                  className="p-3.5 rounded-lg bg-slate-50/80 border border-slate-200/70 hover:border-slate-300 transition-colors flex items-center justify-between gap-4"
                >
                  <div className="flex items-start gap-3 min-w-0">
                    <div className="w-6 h-6 rounded-full bg-amber-100 text-amber-800 text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                      #{idx + 1}
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-slate-900 truncate">
                        {urgent.item.title}
                      </div>
                      <div className="text-[11px] text-slate-500 flex items-center gap-2 mt-0.5">
                        <span className="font-medium text-slate-700">{urgent.item.subject}</span>
                        <span>•</span>
                        <span>Due {new Date(urgent.item.dueDate).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        urgent.item.priority === "High"
                          ? "bg-rose-100 text-rose-700"
                          : urgent.item.priority === "Medium"
                          ? "bg-amber-100 text-amber-700"
                          : "bg-slate-200 text-slate-700"
                      }`}
                    >
                      {urgent.item.priority} Priority
                    </span>
                    <span className="text-xs font-mono font-semibold text-slate-600 bg-white border border-slate-200 px-1.5 py-0.5 rounded">
                      Score: {urgent.priorityScore}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>

          <div className="pt-2 flex items-center justify-end text-xs">
            <button
              onClick={() => onNavigate("assignments")}
              className="text-cyan-600 hover:text-cyan-700 font-semibold inline-flex items-center gap-1"
            >
              <span>Manage all assignments</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Right Col: Nearest Exam Alert & Productivity Factors */}
        <div className="space-y-4">
          {/* Nearest Exam Card */}
          <div className="p-5 rounded-xl bg-gradient-to-br from-indigo-900 to-slate-900 text-white shadow-md">
            <div className="flex items-center justify-between text-xs font-semibold text-indigo-300 mb-2">
              <span className="flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-indigo-400" />
                <span>Upcoming Examination</span>
              </span>
              <span className="px-2 py-0.5 rounded bg-indigo-800 text-indigo-200 text-[10px] uppercase font-bold">
                Exam
              </span>
            </div>

            {nearestExam ? (
              <div className="space-y-2 mt-3">
                <h4 className="text-base font-bold text-white">{nearestExam.title}</h4>
                <p className="text-xs text-indigo-200 flex items-center gap-2">
                  <span>📅 {new Date(nearestExam.startDate).toLocaleDateString("en-US", { month: "short", day: "numeric", weekday: "short" })}</span>
                  {nearestExam.location && <span>• {nearestExam.location}</span>}
                </p>
                {nearestExam.notes && (
                  <p className="text-[11px] text-slate-300 italic line-clamp-2">
                    "{nearestExam.notes}"
                  </p>
                )}
              </div>
            ) : (
              <div className="text-xs text-indigo-200 mt-2">
                No immediate exams scheduled in the upcoming week.
              </div>
            )}

            <button
              onClick={() => onNavigate("calendar")}
              className="mt-4 w-full py-2 bg-indigo-700/60 hover:bg-indigo-700 rounded-lg text-xs font-semibold text-white transition-colors"
            >
              Open Academic Calendar
            </button>
          </div>

          {/* Productivity Factors Breakdown */}
          <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h4 className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                <TrendingUp className="w-3.5 h-3.5 text-emerald-500" />
                <span>Score Breakdown Factors</span>
              </h4>
              <span className="text-[10px] font-mono text-slate-500">Live Telemetry</span>
            </div>
            <div className="mt-3 space-y-2">
              {productivityData?.factors && productivityData.factors.length > 0 ? (
                productivityData.factors.slice(0, 3).map((f, i) => (
                  <div key={i} className="text-xs flex items-center justify-between">
                    <span className="text-slate-600 truncate max-w-[200px]">{f.description}</span>
                    <span
                      className={`font-mono font-bold text-[11px] ${
                        f.impact >= 0 ? "text-emerald-600" : "text-rose-600"
                      }`}
                    >
                      {f.impact >= 0 ? `+${f.impact}` : f.impact}
                    </span>
                  </div>
                ))
              ) : (
                <div className="text-xs text-slate-400">Regular study logs maintain high score.</div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Section: Recent Activity (Stack) */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-cyan-600" />
            <h3 className="text-sm font-bold text-slate-900">
              Recent Activity
            </h3>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
          {productivityData?.recentActivities && productivityData.recentActivities.length > 0 ? (
            productivityData.recentActivities.slice(0, 4).map((log) => (
              <div
                key={log.id}
                className="p-3 rounded-lg bg-slate-50 border border-slate-100 text-left space-y-1"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-700 bg-cyan-50 px-1.5 py-0.5 rounded">
                    {log.entityType}
                  </span>
                  <span className="text-[10px] text-slate-400">
                    {new Date(log.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </span>
                </div>
                <p className="text-xs font-semibold text-slate-800 line-clamp-2">
                  {log.description}
                </p>
              </div>
            ))
          ) : (
            <div className="col-span-4 py-4 text-center text-xs text-slate-400">
              No recent activity recorded yet.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
