import React, { useState, useEffect } from "react";
import {
  GraduationCap,
  Plus,
  TrendingUp,
  Award,
  AlertCircle,
  BarChart2,
  Trash2,
  X,
  Zap,
} from "lucide-react";
import { MarkRecord, MarksAnalytics } from "../types";
import { api } from "../services/api";

export const MarksView: React.FC = () => {
  const [marks, setMarks] = useState<MarkRecord[]>([]);
  const [analytics, setAnalytics] = useState<MarksAnalytics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Add modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formSubject, setFormSubject] = useState("");
  const [formInternal, setFormInternal] = useState(25);
  const [formExternal, setFormExternal] = useState(65);
  const [formMaxMarks, setFormMaxMarks] = useState(100);
  const [formExamType, setFormExamType] = useState("Semester End");

  const fetchMarks = async () => {
    setLoading(true);
    setError(null);
    try {
      const [listRes, analyticsRes] = await Promise.all([
        api.marks.list(),
        api.marks.analytics(),
      ]);
      setMarks(listRes.marks);
      setAnalytics(analyticsRes);
    } catch (err) {
      console.error(err);
      setError("Failed to load academic marks.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMarks();
  }, []);

  const handleDelete = async (id: string) => {
    if (!window.confirm("Remove this mark record?")) return;
    try {
      await api.marks.delete(id);
      fetchMarks();
    } catch (err) {
      console.error(err);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formSubject) return;

    try {
      await api.marks.create({
        subject: formSubject.trim(),
        internalMarks: Number(formInternal),
        externalMarks: Number(formExternal),
        maxMarks: Number(formMaxMarks),
        examType: formExamType,
      });
      setIsModalOpen(false);
      setFormSubject("");
      fetchMarks();
    } catch (err: any) {
      console.error(err);
      alert(err?.message || "Error saving mark record.");
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2.5">
            <GraduationCap className="w-6 h-6 text-purple-600" />
            <span>Academic Marks & Grade Analytics</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Internal + external evaluations, automatic letter grading, Quick Sort rankings, and semester score distribution.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold shadow-md shadow-purple-600/20 transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add Subject Marks</span>
        </button>
      </div>

      {/* Analytics Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Average %</span>
            <TrendingUp className="w-4 h-4 text-purple-600" />
          </div>
          <div className="mt-2 text-3xl font-extrabold text-slate-900">
            {analytics?.averagePercentage || 0}%
          </div>
          <p className="mt-1 text-xs text-slate-500">
            Across {analytics?.totalSubjects || 0} evaluated subjects.
          </p>
        </div>

        <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Top Performance</span>
            <Award className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-2 text-xl font-bold text-emerald-700 truncate">
            {analytics?.highest?.subject || "N/A"}
          </div>
          <p className="mt-1 text-xs text-slate-500">
            {analytics?.highest ? `${analytics.highest.percentage}% (Grade ${analytics.highest.grade})` : "No scores yet"}
          </p>
        </div>

        <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Lowest Performance</span>
            <AlertCircle className="w-4 h-4 text-amber-600" />
          </div>
          <div className="mt-2 text-xl font-bold text-amber-700 truncate">
            {analytics?.lowest?.subject || "N/A"}
          </div>
          <p className="mt-1 text-xs text-slate-500">
            {analytics?.lowest ? `${analytics.lowest.percentage}% (Grade ${analytics.lowest.grade})` : "No scores yet"}
          </p>
        </div>

        <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">DSA Quick Sort</span>
            <Zap className="w-4 h-4 text-cyan-600" />
          </div>
          <div className="mt-2 text-2xl font-bold text-slate-900 font-mono">
            {analytics?.dsaMetrics ? `${analytics.dsaMetrics.executionTimeMs}ms` : "O(n log n)"}
          </div>
          <p className="mt-1 text-[11px] text-slate-500 font-mono">
            In-place partition sorting
          </p>
        </div>
      </div>

      {/* Grade Distribution Bar Graph */}
      {analytics?.gradeDistribution && (
        <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <BarChart2 className="w-4 h-4 text-purple-600" />
              <span>Semester Grade Distribution</span>
            </h3>
            <span className="text-xs text-slate-500">Letter scale A+ through F</span>
          </div>

          <div className="grid grid-cols-7 gap-2 pt-2">
            {["A+", "A", "B+", "B", "C", "D", "F"].map((grade) => {
              const count = analytics.gradeDistribution[grade] || 0;
              const total = analytics.totalSubjects || 1;
              const pct = Math.round((count / total) * 100);

              return (
                <div key={grade} className="text-center space-y-1">
                  <div className="h-20 bg-slate-100 rounded-lg flex flex-col justify-end p-1 overflow-hidden">
                    <div
                      className={`w-full rounded-md transition-all duration-500 ${
                        grade.startsWith("A")
                          ? "bg-emerald-500"
                          : grade.startsWith("B")
                          ? "bg-purple-500"
                          : grade === "C" || grade === "D"
                          ? "bg-amber-500"
                          : "bg-rose-500"
                      }`}
                      style={{ height: `${Math.max(8, pct)}%` }}
                    />
                  </div>
                  <span className="block text-xs font-bold text-slate-800">{grade}</span>
                  <span className="block text-[10px] text-slate-500">{count} subs</span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Marks List (Sorted by Quick Sort) */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
            Evaluated Courses (Quick Sort Ranked)
          </h3>
          <span className="text-xs text-slate-500 font-medium">
            {marks.length} Subjects Recorded
          </span>
        </div>

        {loading ? (
          <div className="p-12 text-center text-xs text-slate-400">
            <div className="w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
            Loading evaluated scores...
          </div>
        ) : marks.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-400">
            No marks entered yet. Click "Add Subject Marks" to start tracking.
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {analytics?.sortedMarks.map((m) => (
              <div
                key={m.id}
                className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/70 transition-colors"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-bold text-slate-900">{m.subject}</h4>
                    <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-medium">
                      {m.examType}
                    </span>
                  </div>
                  <div className="text-xs text-slate-500 mt-1 flex flex-wrap items-center gap-3">
                    <span>Internal: <strong className="text-slate-800">{m.internalMarks}</strong></span>
                    <span>•</span>
                    <span>External: <strong className="text-slate-800">{m.externalMarks}</strong></span>
                    <span>•</span>
                    <span>Total: <strong className="text-slate-800">{m.totalMarks}</strong> / {m.maxMarks}</span>
                  </div>
                </div>

                <div className="flex items-center gap-4 self-end sm:self-center">
                  <div className="text-right">
                    <div className="text-base font-extrabold text-slate-900">{m.percentage}%</div>
                    <span
                      className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded ${
                        m.grade.startsWith("A")
                          ? "bg-emerald-100 text-emerald-800"
                          : m.grade.startsWith("B")
                          ? "bg-purple-100 text-purple-800"
                          : m.grade === "C" || m.grade === "D"
                          ? "bg-amber-100 text-amber-800"
                          : "bg-rose-100 text-rose-800"
                      }`}
                    >
                      Grade {m.grade}
                    </span>
                  </div>

                  <button
                    onClick={() => handleDelete(m.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                    title="Delete record"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add Marks Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">Add Subject Marks</h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Subject Name *
                </label>
                <input
                  type="text"
                  required
                  value={formSubject}
                  onChange={(e) => setFormSubject(e.target.value)}
                  placeholder="e.g. Design & Analysis of Algorithms"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Examination Type
                </label>
                <select
                  value={formExamType}
                  onChange={(e) => setFormExamType(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                >
                  <option value="Semester End">Semester End Examination</option>
                  <option value="Mid-Term Assessment">Mid-Term Assessment</option>
                  <option value="Internal Lab Assessment">Internal Lab Assessment</option>
                </select>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Internal
                  </label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={formInternal}
                    onChange={(e) => setFormInternal(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    External
                  </label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={formExternal}
                    onChange={(e) => setFormExternal(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Max Marks
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={formMaxMarks}
                    onChange={(e) => setFormMaxMarks(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-50 rounded-xl text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold shadow-md shadow-purple-600/20"
                >
                  Save Marks
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
