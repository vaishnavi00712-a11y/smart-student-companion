import React, { useState, useEffect, useRef } from "react";
import {
  FileText,
  Plus,
  Search,
  Tag,
  Upload,
  Sparkles,
  MessageSquare,
  Trash2,
  Edit2,
  X,
  ExternalLink,
  Bot,
  BrainCircuit,
  FileDown,
} from "lucide-react";
import { Note } from "../types";
import { api } from "../services/api";

export const NotesView: React.FC = () => {
  const [notes, setNotes] = useState<Note[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSubject, setSelectedSubject] = useState("All");

  // Add/Edit modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<Note | null>(null);
  const [formTitle, setFormTitle] = useState("");
  const [formSubject, setFormSubject] = useState("Database Management Systems");
  const [formFolder, setFormFolder] = useState("Lectures");
  const [formContent, setFormContent] = useState("");
  const [formTags, setFormTags] = useState("");
  const [uploadingFile, setUploadingFile] = useState(false);
  const [uploadedFileUrl, setUploadedFileUrl] = useState<string | undefined>(undefined);
  const [uploadedFileName, setUploadedFileName] = useState<string | undefined>(undefined);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // AI Summary Modal / Drawer
  const [summaryModalNote, setSummaryModalNote] = useState<Note | null>(null);
  const [summaryText, setSummaryText] = useState("");
  const [summarizing, setSummarizing] = useState(false);

  // RAG Search Drawer
  const [isRagOpen, setIsRagOpen] = useState(false);
  const [ragQuery, setRagQuery] = useState("");
  const [ragLoading, setRagLoading] = useState(false);
  const [ragResult, setRagResult] = useState<{
    answer: string;
    retrievedChunks: { id: string; title: string; subject: string; similarity: number }[];
    algorithmMetrics: any;
  } | null>(null);

  const fetchNotes = async () => {
    setLoading(true);
    try {
      const res = await api.notes.list({
        search: searchQuery,
        subject: selectedSubject === "All" ? undefined : selectedSubject,
      });
      setNotes(res.notes);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNotes();
  }, [selectedSubject]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchNotes();
  };

  const handleOpenAdd = () => {
    setEditingNote(null);
    setFormTitle("");
    setFormSubject("Database Management Systems");
    setFormFolder("Lectures");
    setFormContent("");
    setFormTags("exams, revision");
    setUploadedFileUrl(undefined);
    setUploadedFileName(undefined);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (note: Note) => {
    setEditingNote(note);
    setFormTitle(note.title);
    setFormSubject(note.subject);
    setFormFolder(note.folder || "Lectures");
    setFormContent(note.content);
    setFormTags(note.tags.join(", "));
    setUploadedFileUrl(note.fileUrl);
    setUploadedFileName(note.fileName);
    setIsModalOpen(true);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const formData = new FormData();
    formData.append("file", file);

    setUploadingFile(true);
    try {
      const res = await api.notes.uploadFile(formData);
      setUploadedFileUrl(res.fileUrl);
      setUploadedFileName(res.fileName);
    } catch (err: any) {
      console.error(err);
      alert(err?.message || "Error uploading file. Allowed: PDF, PNG, JPG under 10MB.");
    } finally {
      setUploadingFile(false);
    }
  };

  const handleSaveNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle || !formContent) return;

    const tagsArray = formTags
      .split(",")
      .map((t) => t.trim())
      .filter(Boolean);

    try {
      if (editingNote) {
        await api.notes.update(editingNote.id, {
          title: formTitle,
          content: formContent,
          subject: formSubject,
          folder: formFolder,
          tags: tagsArray,
          fileUrl: uploadedFileUrl,
          fileName: uploadedFileName,
        });
      } else {
        await api.notes.create({
          title: formTitle,
          content: formContent,
          subject: formSubject,
          folder: formFolder,
          tags: tagsArray,
          fileUrl: uploadedFileUrl,
          fileName: uploadedFileName,
        });
      }
      setIsModalOpen(false);
      fetchNotes();
    } catch (err: any) {
      console.error(err);
      alert(err?.message || "Error saving note");
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm("Delete this lecture note?")) return;
    try {
      await api.notes.delete(id);
      fetchNotes();
    } catch (err) {
      console.error(err);
    }
  };

  const handleSummarizeNote = async (note: Note) => {
    setSummaryModalNote(note);
    setSummaryText("");
    setSummarizing(true);
    try {
      const res = await api.ai.summarize(note.title, note.content);
      setSummaryText(res.summary);
    } catch (err: any) {
      setSummaryText("Unable to generate summary. Please ensure server is reachable.");
    } finally {
      setSummarizing(false);
    }
  };

  const handleRagSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ragQuery.trim()) return;
    setRagLoading(true);
    setRagResult(null);
    try {
      const res = await api.ai.ragSearch(ragQuery);
      setRagResult(res);
    } catch (err: any) {
      console.error(err);
      alert(err?.message || "RAG search query failed.");
    } finally {
      setRagLoading(false);
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2.5">
            <FileText className="w-6 h-6 text-cyan-600" />
            <span>Smart Lecture Notes & AI RAG Engine</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Upload PDFs/images, organize by subject folders, generate AI exam summaries, and search via Cosine Similarity RAG.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setIsRagOpen(true)}
            className="inline-flex items-center gap-2 px-3.5 py-2.5 bg-gradient-to-r from-indigo-50 to-cyan-50 border border-indigo-200 text-indigo-700 hover:border-indigo-300 rounded-xl text-xs font-bold shadow-xs transition-all"
          >
            <BrainCircuit className="w-4 h-4 text-indigo-600" />
            <span>RAG Query Notes</span>
          </button>

          <button
            onClick={handleOpenAdd}
            className="inline-flex items-center gap-2 px-4 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold shadow-md shadow-cyan-600/20 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>New Note</span>
          </button>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        <form onSubmit={handleSearchSubmit} className="relative flex-1 w-full max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search notes by title, tag, or content keywords..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-16 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
          />
          <button
            type="submit"
            className="absolute right-1.5 top-1/2 -translate-y-1/2 px-2.5 py-1 bg-slate-200 hover:bg-slate-300 text-slate-700 text-[11px] font-semibold rounded"
          >
            Search
          </button>
        </form>

        <div className="flex items-center gap-2 w-full md:w-auto">
          <label className="text-xs text-slate-500 font-medium shrink-0">Subject:</label>
          <select
            value={selectedSubject}
            onChange={(e) => setSelectedSubject(e.target.value)}
            className="w-full md:w-auto bg-slate-50 border border-slate-200 text-slate-800 text-xs rounded-lg px-3 py-1.5 font-medium"
          >
            <option value="All">All Subjects</option>
            <option value="Database Management Systems">Database Management Systems</option>
            <option value="Operating Systems">Operating Systems</option>
            <option value="Computer Networks">Computer Networks</option>
            <option value="Design & Analysis of Algorithms">Design & Analysis of Algorithms</option>
          </select>
        </div>
      </div>

      {/* Notes Grid */}
      {loading ? (
        <div className="p-12 text-center text-xs text-slate-400">
          <div className="w-8 h-8 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
          Loading lecture notes...
        </div>
      ) : notes.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-xl border border-slate-200 space-y-3">
          <FileText className="w-10 h-10 text-slate-300 mx-auto" />
          <h3 className="text-sm font-bold text-slate-800">No notes found</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Create your first rich study note or upload a PDF syllabus.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {notes.map((note) => (
            <div
              key={note.id}
              className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs hover:border-slate-300 transition-all flex flex-col justify-between space-y-4"
            >
              <div className="space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-700 bg-cyan-50 px-2 py-0.5 rounded border border-cyan-100">
                    {note.subject}
                  </span>
                  <span className="text-[10px] text-slate-400">
                    {new Date(note.updatedAt).toLocaleDateString()}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-slate-900 line-clamp-1">{note.title}</h3>
                <p className="text-xs text-slate-600 line-clamp-4 leading-relaxed">
                  {note.content}
                </p>

                {note.fileName && (
                  <a
                    href={note.fileUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 text-[11px] font-medium text-indigo-600 hover:text-indigo-700 bg-indigo-50/70 px-2 py-1 rounded"
                  >
                    <FileDown className="w-3 h-3" />
                    <span className="truncate max-w-[180px]">{note.fileName}</span>
                  </a>
                )}

                {note.tags && note.tags.length > 0 && (
                  <div className="flex flex-wrap items-center gap-1 pt-1">
                    {note.tags.map((t) => (
                      <span
                        key={t}
                        className="text-[10px] text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded"
                      >
                        #{t}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              {/* Card Footer Actions */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <button
                  onClick={() => handleSummarizeNote(note)}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-600 hover:text-indigo-700 bg-indigo-50 hover:bg-indigo-100 px-2.5 py-1 rounded-lg transition-colors"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>AI Summary</span>
                </button>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleOpenEdit(note)}
                    className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
                    title="Edit Note"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(note.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg"
                    title="Delete Note"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* RAG Ask Question Drawer / Modal */}
      {isRagOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 max-h-[85vh] overflow-y-auto space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <BrainCircuit className="w-5 h-5 text-indigo-600" />
                <h3 className="text-base font-bold text-slate-900">
                  RAG Assistant (Cosine Similarity Retrieval)
                </h3>
              </div>
              <button
                onClick={() => setIsRagOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-500">
              Ask any academic question. The system calculates token vector dot products{" "}
              <code className="bg-slate-100 px-1 rounded text-indigo-600 font-mono">
                (A·B)/(||A||×||B||)
              </code>{" "}
              against all your notes, retrieves the top matching chunks, and feeds them into the Gemini model.
            </p>

            <form onSubmit={handleRagSearch} className="space-y-3">
              <textarea
                rows={3}
                required
                value={ragQuery}
                onChange={(e) => setRagQuery(e.target.value)}
                placeholder="e.g. What is the difference between clustered and non-clustered indexing in databases?"
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
              />
              <button
                type="submit"
                disabled={ragLoading}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-600/20 disabled:opacity-50 flex items-center gap-2"
              >
                {ragLoading ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Computing Vector Similarity & Generating...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Run RAG Retrieval</span>
                  </>
                )}
              </button>
            </form>

            {ragResult && (
              <div className="mt-4 space-y-4 pt-4 border-t border-slate-100">
                {/* Retrieved context chunks */}
                <div className="space-y-2">
                  <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Retrieved Knowledge Chunks:</span>
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {ragResult.retrievedChunks.map((chunk) => (
                      <div
                        key={chunk.id}
                        className="p-2.5 rounded-lg bg-indigo-50/60 border border-indigo-100 text-xs flex items-center justify-between"
                      >
                        <div className="truncate pr-2">
                          <strong className="text-indigo-900 block truncate">{chunk.title}</strong>
                          <span className="text-[10px] text-indigo-600">{chunk.subject}</span>
                        </div>
                        <span className="text-[10px] font-mono font-bold bg-white px-1.5 py-0.5 rounded border border-indigo-200 text-indigo-800">
                          {Math.round(chunk.similarity * 100)}% Match
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* AI Answer */}
                <div className="p-4 rounded-xl bg-slate-900 text-slate-100 space-y-2 text-xs leading-relaxed">
                  <div className="flex items-center gap-1.5 text-cyan-400 font-bold text-xs pb-1 border-b border-slate-800">
                    <Bot className="w-4 h-4" />
                    <span>AI Tutor Grounded Answer:</span>
                  </div>
                  <div className="whitespace-pre-wrap">{ragResult.answer}</div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* AI Summary Modal */}
      {summaryModalNote && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-indigo-600" />
                <span>AI Exam Takeaways: {summaryModalNote.title}</span>
              </h3>
              <button
                onClick={() => setSummaryModalNote(null)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {summarizing ? (
              <div className="p-8 text-center text-xs text-slate-500 space-y-2">
                <div className="w-8 h-8 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto" />
                <p>Synthesizing key formulas, bullet points, and exam definitions...</p>
              </div>
            ) : (
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 whitespace-pre-wrap leading-relaxed max-h-96 overflow-y-auto">
                {summaryText}
              </div>
            )}

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setSummaryModalNote(null)}
                className="px-4 py-2 bg-slate-900 text-white rounded-xl text-xs font-semibold"
              >
                Close Summary
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add / Edit Note Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">
                {editingNote ? "Edit Lecture Note" : "Create New Lecture Note"}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveNote} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Note Title *
                </label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="e.g. B-Trees vs B+ Trees Architecture"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Subject *
                  </label>
                  <select
                    value={formSubject}
                    onChange={(e) => setFormSubject(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                  >
                    <option value="Database Management Systems">Database Management Systems</option>
                    <option value="Operating Systems">Operating Systems</option>
                    <option value="Computer Networks">Computer Networks</option>
                    <option value="Design & Analysis of Algorithms">Design & Analysis of Algorithms</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Folder Name
                  </label>
                  <input
                    type="text"
                    value={formFolder}
                    onChange={(e) => setFormFolder(e.target.value)}
                    placeholder="e.g. Unit 3"
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Tags (comma separated)
                </label>
                <input
                  type="text"
                  value={formTags}
                  onChange={(e) => setFormTags(e.target.value)}
                  placeholder="indexing, b-tree, storage, exams"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Note Content / Lecture Transcript *
                </label>
                <textarea
                  rows={6}
                  required
                  value={formContent}
                  onChange={(e) => setFormContent(e.target.value)}
                  placeholder="Type or paste lecture notes, algorithms, equations, or key summaries..."
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono"
                />
              </div>

              {/* File Attachment Upload */}
              <div className="p-3 rounded-lg border border-dashed border-slate-200 bg-slate-50 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Upload className="w-4 h-4 text-slate-500" />
                  <div className="text-xs">
                    <span className="font-semibold text-slate-700">Attach Document</span>
                    <span className="text-slate-400 block text-[10px]">
                      {uploadedFileName ? `Attached: ${uploadedFileName}` : "PDF, PNG, or JPG up to 10MB"}
                    </span>
                  </div>
                </div>

                <div>
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileUpload}
                    accept=".pdf,.png,.jpg,.jpeg"
                    className="hidden"
                  />
                  <button
                    type="button"
                    disabled={uploadingFile}
                    onClick={() => fileInputRef.current?.click()}
                    className="px-3 py-1.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg text-xs font-semibold"
                  >
                    {uploadingFile ? "Uploading..." : "Select File"}
                  </button>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-50 rounded-xl text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold shadow-md shadow-cyan-600/20"
                >
                  Save Note
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
