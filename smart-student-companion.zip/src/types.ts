export interface User {
  id: string;
  name: string;
  email: string;
  course: string;
  year: string;
  college: string;
  avatarUrl?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Assignment {
  id: string;
  userId: string;
  title: string;
  description: string;
  subject: string;
  priority: "Low" | "Medium" | "High";
  status: "Pending" | "In Progress" | "Completed";
  dueDate: string;
  createdAt: string;
  updatedAt: string;
}

export interface DsaMetrics {
  algorithm: string;
  bestCase: string;
  averageCase: string;
  worstCase: string;
  spaceComplexity: string;
  executionTimeMs: number;
  comparisons: number;
}

export interface UrgentItem {
  item: Assignment;
  priorityScore: number;
}

export interface AttendanceRecord {
  id: string;
  userId: string;
  subject: string;
  present: number;
  total: number;
  percentage: number;
  status: "Safe" | "Warning" | "Shortage";
  classesNeededTo75: number;
  classesCanMiss: number;
  updatedAt: string;
}

export interface AttendanceSummary {
  overallPercentage: number;
  totalSubjects: number;
  safeCount: number;
  shortageCount: number;
  warningCount: number;
}

export interface MarkRecord {
  id: string;
  userId: string;
  subject: string;
  internalMarks: number;
  externalMarks: number;
  maxMarks: number;
  totalMarks: number;
  percentage: number;
  grade: string;
  examType: string;
  updatedAt: string;
}

export interface MarksAnalytics {
  totalSubjects: number;
  averagePercentage: number;
  highest: MarkRecord | null;
  lowest: MarkRecord | null;
  gradeDistribution: Record<string, number>;
  sortedMarks: MarkRecord[];
  dsaMetrics?: DsaMetrics;
}

export interface Note {
  id: string;
  userId: string;
  title: string;
  content: string;
  subject: string;
  folder?: string;
  tags: string[];
  fileUrl?: string;
  fileName?: string;
  createdAt: string;
  updatedAt: string;
}

export interface StudyGoal {
  id: string;
  userId: string;
  title: string;
  subject: string;
  targetHours: number;
  completedHours: number;
  progressPercentage: number;
  deadline: string;
  status: "active" | "completed";
  createdAt: string;
}

export interface PomodoroSession {
  id: string;
  userId: string;
  subject: string;
  durationMinutes: number;
  startTime: string;
  endTime: string;
  completed: boolean;
  notes?: string;
}

export interface StudyStats {
  totalSessions: number;
  dailyStudyHours: number;
  weeklyStudyHours: number;
  monthlyStudyHours: number;
  subjectBreakdown: Record<string, number>;
  recentSessions: PomodoroSession[];
}

export interface CalendarEvent {
  id: string;
  userId: string;
  title: string;
  eventType: "Assignment Deadline" | "Exam" | "Study Session" | "College Event" | "Personal Event";
  startDate: string;
  endDate?: string;
  location?: string;
  notes?: string;
}

export interface NotificationItem {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: "warning" | "info" | "success" | "reminder";
  read: boolean;
  createdAt: string;
}

export interface ProductivityData {
  productivityScore: number;
  factors: {
    label: string;
    impact: number;
    description: string;
  }[];
  metrics: {
    completedAssignments: number;
    totalAssignments: number;
    attendanceAvg: number;
    studyHoursThisWeek: number;
    targetStudyHours: number;
    completedGoals: number;
    pomodoroSessionsCount: number;
  };
  recentActivities: {
    id: string;
    action: string;
    entityType: string;
    description: string;
    timestamp: string;
  }[];
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface Flashcard {
  id: string;
  userId: string;
  subject: string;
  question: string;
  answer: string;
  difficulty: "Easy" | "Medium" | "Hard";
  reviewedCount: number;
  lastReviewed?: string;
}
